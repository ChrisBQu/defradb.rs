#!/usr/bin/env python3
"""Package completed frozen benchmark runs without binaries or build targets.

Example (only after all expected labels are complete and timing is over):
  python3 /tmp/defra-pack-frozen-evidence.py \
    --artifact-root /tmp/defra-perf-artifacts \
    --labels-json /tmp/defra-perf-artifacts/final-label-mapping.json \
    --worktree /path/to/clean/defradb-checkout \
    --output /tmp/defra-perf-artifacts/portable-package

The script refuses partial runs, missing provenance, failed commands, modified
source revisions, a live frozen runner/benchmark process, or oversized archives.
It emits one bounded .tar.gz per revision plus a support archive and an
index.json containing SHA-256 hashes for every packaged member/archive.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import tempfile

MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
REQUIRED_COMMANDS = {"write_baseline", "document_write", "startup",
                     "allocs-1", "allocs-2", "allocs-3", "allocs-4", "allocs-5"}
CRITERION_PATHS = {
    "document_create/4": ("document_write", "document_create/4"),
    "document_create/16": ("document_write", "document_create/16"),
    "document_create_branchable/14": ("document_write", "document_create_branchable/14"),
    "startup/cold_open/embedded/10_collections": ("startup", "startup/cold_open_embedded_10_collections"),
}
REQUIRED_CRITERION_IDS = set(CRITERION_PATHS)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_rel(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def archive_gz(out_path: Path, members: list[tuple[Path, str]], max_bytes: int) -> dict:
    """Write deterministic gzip-compressed tar; member list is (source, arcname)."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix="defra-evidence-", suffix=".tar", dir=out_path.parent,
                                     delete=False) as raw:
        raw_name = Path(raw.name)
    try:
        with tarfile.open(raw_name, "w", format=tarfile.PAX_FORMAT) as tf:
            for source, arcname in sorted(members, key=lambda item: item[1]):
                info = tf.gettarinfo(str(source), arcname=arcname)
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                info.mtime = 0
                with source.open("rb") as f:
                    tf.addfile(info, f)
        with raw_name.open("rb") as src, out_path.open("wb") as dst:
            with gzip.GzipFile(filename="", mode="wb", fileobj=dst, mtime=0, compresslevel=6) as gz:
                for chunk in iter(lambda: src.read(1024 * 1024), b""):
                    gz.write(chunk)
        size = out_path.stat().st_size
        if size > max_bytes:
            out_path.unlink(missing_ok=True)
            raise ValueError(f"archive exceeds limit ({size} > {max_bytes} bytes): {out_path}")
        return {"path": out_path.name, "size_bytes": size, "sha256": sha256(out_path),
                "members": [{"path": arc, "size_bytes": src.stat().st_size, "sha256": sha256(src)}
                            for src, arc in sorted(members, key=lambda item: item[1])]}
    finally:
        raw_name.unlink(missing_ok=True)


def verify_completed_run(label: str, gate_dir: Path, build_dir: Path, mapping: dict) -> dict:
    run_path = gate_dir / "RUN.json"
    if not run_path.is_file():
        raise ValueError(f"missing RUN.json for {label}")
    run = json.loads(run_path.read_text())
    if run.get("label") != label or run.get("complete") is not True:
        raise ValueError(f"run incomplete or label mismatch: {label}")
    if run.get("revision") != mapping.get("commit"):
        raise ValueError(f"built/run revision mismatch for {label}")
    if mapping.get("build_revision") != run.get("revision") or mapping.get("dirty") is not False:
        raise ValueError(f"build manifest commit/clean-tree mismatch for {label}")
    for name, expected_hash in run.get("sha256", {}).items():
        binary = build_dir / name
        if not binary.is_file() or sha256(binary) != expected_hash:
            raise ValueError(f"built executable missing/hash mismatch for {label}/{name}")
        mapped_hash = mapping.get("executable_sha256", {}).get(name)
        if mapped_hash and mapped_hash != expected_hash:
            raise ValueError(f"build manifest executable hash mismatch for {label}/{name}")
    if run.get("profile") != "release-fast":
        raise ValueError(f"unexpected benchmark profile for {label}: {run.get('profile')}")
    commands = run.get("commands", [])
    names = {c.get("name") for c in commands}
    if names != REQUIRED_COMMANDS:
        raise ValueError(f"unexpected command set for {label}: {sorted(names)}")
    criterion_ids = set()
    for command in commands:
        criterion_ids.update(command.get("criterion_estimates", {}).keys())
        if command.get("exit_code") != 0 or command.get("artifacts_valid") is not True:
            raise ValueError(f"command failed or artifacts invalid: {label}/{command.get('name')}")
        for field in ("log_path", "families_path"):
            value = command.get(field)
            if not value:
                raise ValueError(f"missing {field}: {label}/{command.get('name')}")
            p = Path(value)
            if not p.is_file():
                raise ValueError(f"missing recorded artifact: {p}")
            expected = command.get("log_sha256") if field == "log_path" else command.get("families_sha256")
            if expected and sha256(p) != expected:
                raise ValueError(f"recorded digest mismatch: {p}")
        for estimate in command.get("criterion_estimates", {}).values():
            p = Path(estimate["path"])
            if not p.is_file() or sha256(p) != estimate.get("sha256"):
                raise ValueError(f"missing/mismatched Criterion estimate: {p}")
    if criterion_ids != REQUIRED_CRITERION_IDS:
        raise ValueError(f"Criterion estimate set mismatch for {label}: {sorted(criterion_ids)}")
    # All attempts, including rejected load guards, are preserved and checked.
    for attempt in run.get("guard_attempts", []):
        p = Path(attempt.get("path", ""))
        if not p.is_file() or (attempt.get("guard_sha256") and sha256(p) != attempt["guard_sha256"]):
            raise ValueError(f"missing/mismatched load guard record: {p}")
    builds = [build_dir / "BUILD.json", build_dir / "BUILD.txt"]
    build = next((p for p in builds if p.is_file()), None)
    if build is None:
        raise ValueError(f"missing BUILD metadata for {label}")
    if build.suffix == ".json":
        meta = json.loads(build.read_text())
        built_revision = meta.get("revision") or meta.get("source_revision")
        if built_revision and not str(run["revision"]).startswith(str(built_revision)) and not str(built_revision).startswith(str(run["revision"])):
            raise ValueError(f"BUILD revision mismatch for {label}")
        if meta.get("dirty") is not False:
            raise ValueError(f"BUILD metadata is not clean for {label}")
    else:
        text = build.read_text()
        if f"Revision: {run['revision']}" not in text or "Tree: clean at build" not in text:
            raise ValueError(f"BUILD.txt provenance mismatch for {label}")
    return {"run": run, "run_path": run_path, "build_path": build}


def record_member(members: dict[str, Path], src: Path, arc: str) -> None:
    if not src.is_file():
        raise ValueError(f"required evidence absent: {src}")
    # Defend against accidental binary/target inclusion.
    if any(part in {"target", "debug", "release", "release-fast", "super-dev"} for part in src.parts):
        raise ValueError(f"refusing build output: {src}")
    members[arc] = src


def gate_members(label: str, gate_dir: Path, build_path: Path, gate_root: Path) -> list[tuple[Path, str]]:
    members: dict[str, Path] = {}
    record_member(members, gate_dir / "RUN.json", f"gates/{label}/RUN.json")
    record_member(members, build_path, f"build-metadata/{label}/{build_path.name}")
    run = json.loads((gate_dir / "RUN.json").read_text())
    # Include every recorded primary log, Family JSONL, and every load-guard attempt.
    for command in run["commands"]:
        for field in ("log_path", "families_path"):
            src = Path(command[field])
            record_member(members, src, f"gates/{label}/{src.name}")
        for field in ("guard_path",):
            if command.get(field):
                src = Path(command[field]); record_member(members, src, f"gates/{label}/{src.name}")
    for attempt in run.get("guard_attempts", []):
        src = Path(attempt["path"])
        record_member(members, src, f"gates/{label}/{src.name}")
    # Keep Criterion machine-readable raw samples, estimates and metadata, omit rendered HTML/SVG.
    criterion_root = gate_dir / "criterion-output"
    if criterion_root.exists():
        for src in criterion_root.rglob("*.json"):
            record_member(members, src, f"gates/{label}/criterion-output/{src.relative_to(criterion_root).as_posix()}")
    json_members = set(members)
    for benchmark_id, (stem, criterion_id) in CRITERION_PATHS.items():
        rel = "/".join(["gates", label, "criterion-output", stem, "criterion", criterion_id, "new"])
        for name in ("estimates.json", "sample.json", "benchmark.json"):
            if f"{rel}/{name}" not in json_members:
                raise ValueError(f"missing Criterion {name} for {label}/{benchmark_id}")
    return [(src, arc) for arc, src in members.items()]


def support_members(artifact_root: Path, worktree: Path) -> list[tuple[Path, str]]:
    members: dict[str, Path] = {}
    fixed = [
        (artifact_root / "final-label-mapping.json", "provenance/final-label-mapping.json"),
        (artifact_root / "provenance-scope-addendum.json", "provenance/provenance-scope-addendum.json"),
        (artifact_root / "runner-paused-for-native-acp.json", "provenance/runner-paused-for-native-acp.json"),
        (artifact_root / "resume-loadguard.json", "provenance/resume-loadguard.json"),
        (artifact_root / "benches-cargo-tree-all.txt", "provenance/benches-cargo-tree-all.txt"),
        (Path("/tmp/defra-perf-full-run.log"), "provenance/defra-perf-full-run.log"),
        (worktree / "tools/regolith-gates/build.py", "tools/regolith-gates/build.py"),
        (worktree / "tools/regolith-gates/run.py", "tools/regolith-gates/run.py"),
        (worktree / "tools/regolith-gates/analyze.py", "tools/regolith-gates/analyze.py"),
        (worktree / "tools/regolith-gates/README.md", "tools/regolith-gates/README.md"),
        (worktree / "docs/benchmarks/regolith-main-532aac3f/README.md", "reference/main-532aac3f/README.md"),
        (worktree / "docs/benchmarks/regolith-main-532aac3f/provenance/RUN.portable.json", "reference/main-532aac3f/RUN.portable.json"),
        (worktree / "docs/benchmarks/regolith-main-532aac3f/SHA256SUMS", "reference/main-532aac3f/SHA256SUMS"),
        (Path("/tmp/defra-run-frozen-gates.py"), "tools/run-frozen-gates.py"),
        (Path("/tmp/defra-analyze-frozen-gates.py"), "tools/analyze-frozen-gates.py"),
        (Path("/tmp/defra-pack-frozen-evidence.py"), "tools/pack-frozen-evidence.py"),
        (worktree / "tools/perf-site/loadguard.py", "tools/loadguard.py"),
    ]
    for src, arc in fixed:
        record_member(members, src, arc)
    analyses = list(artifact_root.glob("analysis-*.md")) + list(artifact_root.glob("analysis-*.json"))
    analyses += list(artifact_root.glob("prep0-findings.md"))
    if not analyses:
        raise ValueError("no analyzer reports found")
    for src in analyses:
        record_member(members, src, f"analysis/{src.name}")
    # Include generated portable packaging guidance. The source provenance and
    # BUILD metadata remain byte-for-byte unchanged; this README only explains
    # archive verification and evidence limits.
    return [(src, arc) for arc, src in members.items()]



def historical_reference_members(artifact_root: Path, worktree: Path) -> tuple[list[tuple[Path, str]], dict]:
    """Validate and preserve the pre-series 532 baseline stored as a gate extra."""
    label = "main-532aac3f"
    gate = artifact_root / "gates" / label
    build_dir = artifact_root / "bin" / label
    run_path = gate / "RUN.json"
    if not run_path.is_file():
        raise ValueError("unexpected gate directory lacks historical RUN.json")
    run = json.loads(run_path.read_text())
    if (run.get("label") != label or run.get("revision") != "532aac3fd06a61c319c2d5fbde84da42aab67f0d"
            or run.get("complete") is not True or run.get("profile") != "release-fast"):
        raise ValueError("unexpected gate directory is not the known complete main-532aac3f reference")
    ref = worktree / "docs/benchmarks/regolith-main-532aac3f"
    if sha256(run_path) != sha256(ref / "provenance/RUN.json"):
        raise ValueError("historical main-532 gate RUN.json differs from committed reference")
    build_path = build_dir / "BUILD.txt"
    if not build_path.is_file():
        raise ValueError("historical main-532 build metadata is missing")
    build_text = build_path.read_text()
    if f"Revision: {run['revision']}" not in build_text or "Tree: clean at build" not in build_text:
        raise ValueError("historical main-532 BUILD.txt provenance mismatch")
    # Verify original executable identities but never place executable bytes in archives.
    for name, digest in run.get("sha256", {}).items():
        binary = build_dir / name
        if not binary.is_file() or sha256(binary) != digest:
            raise ValueError(f"historical main-532 executable identity mismatch: {name}")
    members: dict[str, Path] = {}
    def add(src: Path, arc: str) -> None:
        record_member(members, src, arc)
    add(run_path, f"historical/{label}/gates/RUN.json")
    add(build_path, f"historical/{label}/build-metadata/BUILD.txt")
    for command in run.get("commands", []):
        if command.get("exit_code") != 0 or command.get("artifacts_valid") is not True:
            raise ValueError(f"historical command failed: {command.get('name')}")
        for field, digest_field in (("log_path", "log_sha256"), ("families_path", "families_sha256"), ("guard_path", "guard_sha256")):
            value = command.get(field)
            if value:
                src = Path(value)
                if not src.is_file() or sha256(src) != command.get(digest_field):
                    raise ValueError(f"historical command artifact mismatch: {src}")
                add(src, f"historical/{label}/gates/{src.name}")
    for attempt in run.get("guard_attempts", []):
        src = Path(attempt["path"])
        if not src.is_file() or sha256(src) != attempt.get("guard_sha256"):
            raise ValueError(f"historical load-guard mismatch: {src}")
        add(src, f"historical/{label}/gates/{src.name}")
    criterion_root = gate / "criterion-output"
    for src in criterion_root.rglob("*.json"):
        add(src, f"historical/{label}/criterion/{src.relative_to(criterion_root).as_posix()}")
    for src in build_dir.glob("ALLOCATIONS*"):
        if src.is_file() and src.suffix in {".txt", ".raw", ".sha256"}:
            add(src, f"historical/{label}/allocations/{src.name}")
    return [(src, arc) for arc, src in members.items()], run

def active_runner_detected() -> bool:
    try:
        out = subprocess.check_output(["ps", "-ax", "-o", "command="], text=True)
    except (OSError, subprocess.CalledProcessError):
        return False
    return any(("defra-run-frozen-gates.py" in line or "defra-analyze-frozen-gates.py" in line
                 or "/defra-perf-artifacts/bin/" in line
                 or "cargo bench -p benches" in line)
               for line in out.splitlines()
               if "defra-pack-frozen-evidence.py" not in line)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--artifact-root", type=Path, required=True, help="directory containing gates/, bin/, and provenance")
    ap.add_argument("--labels-json", type=Path, required=True, help="final-label-mapping.json with 22 built labels")
    ap.add_argument("--output", type=Path, required=True, help="new output directory for archives/index")
    ap.add_argument("--worktree", type=Path, required=True, help="clean repository checkout containing the guard script")
    ap.add_argument("--max-archive-mib", type=int, default=64)
    ap.add_argument("--max-total-mib", type=int, default=256)
    ap.add_argument("--expected-label-count", type=int, default=22)
    args = ap.parse_args()
    artifact_root = args.artifact_root.resolve()
    out = args.output.resolve()
    if out.exists():
        raise ValueError(f"output directory must not exist: {out}")
    out.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=out.name + ".staging-", dir=out.parent))
    if active_runner_detected():
        raise ValueError("a frozen runner is active; refusing to read/package files")
    mapping_doc = json.loads(args.labels_json.read_text())
    builds = mapping_doc.get("builds", [])
    if len(builds) != args.expected_label_count:
        raise ValueError(f"expected {args.expected_label_count} revision records, found {len(builds)}")
    expected_labels = [b["label"] for b in builds]
    if len(set(expected_labels)) != len(expected_labels):
        raise ValueError("duplicate label in provenance mapping")
    gate_root = artifact_root / "gates"
    binary_root = artifact_root / "bin"
    prepared = []
    for entry in builds:
        label = entry["label"]
        verified = verify_completed_run(label, gate_root / label, binary_root / label, entry)
        members = gate_members(label, gate_root / label, verified["build_path"], gate_root)
        # Allocation artifacts are raw numeric output, not executables.
        build_dir = binary_root / label
        for src in build_dir.glob("ALLOCATIONS*"):
            if src.is_file() and src.suffix in {".txt", ".raw", ".sha256"}:
                members.append((src, f"allocations/{label}/{src.name}"))
        prepared.append((label, verified, members, entry))
    actual_dirs = {p.name for p in gate_root.iterdir() if p.is_dir()}
    missing = set(expected_labels) - actual_dirs
    extra = actual_dirs - set(expected_labels)
    if missing or extra - {"main-532aac3f"}:
        raise ValueError(f"gate label set mismatch; missing={sorted(missing)}, extra={sorted(extra-set(expected_labels))}")
    cap = args.max_archive_mib * 1024 * 1024
    total_cap = args.max_total_mib * 1024 * 1024
    archives = []
    label_artifacts = {}
    # Archive raw allocation runs and a portable per-label manifest. Executables
    # are deliberately omitted: hashes identify the originals but do not make a
    # rebuild at a different path/toolchain equivalent.
    for label, verified, members, entry in prepared:
        artifact_rows = [
            {"path": arc, "sha256": sha256(src), "size_bytes": src.stat().st_size}
            for src, arc in sorted(members, key=lambda item: item[1])
        ]
        build_meta_arc = f"build-metadata/{label}/{verified['build_path'].name}"
        portable = {
            "format_version": 1,
            "label": label,
            "revision": verified["run"]["revision"],
            "profile": verified["run"]["profile"],
            "original_run": {
                "path": f"gates/{label}/RUN.json",
                "sha256": sha256(verified["run_path"]),
                "preserved_verbatim": True,
            },
            "build_metadata": {
                "path": build_meta_arc,
                "sha256": sha256(verified["build_path"]),
                "preserved_verbatim": True,
            },
            "executables": {
                "included": False,
                "reason": "Frozen binaries are intentionally omitted from this evidence package.",
                "recorded_original_sha256": verified["run"].get("sha256", {}),
                "rebuild_note": "A rebuild at a different path/toolchain is a new executable and cannot be claimed to match the recorded binary identity without matching its SHA-256.",
            },
            "artifacts": artifact_rows,
        }
        portable_path = staging / f"{label}.RUN.portable.json"
        portable_path.write_text(json.dumps(portable, indent=2) + "\n")
        members.append((portable_path, f"gates/{label}/RUN.portable.json"))
        label_artifacts[label] = artifact_rows + [
            {"path": f"gates/{label}/RUN.portable.json", "sha256": sha256(portable_path), "size_bytes": portable_path.stat().st_size}
        ]
        archives.append(archive_gz(staging / f"{label}.tar.gz", members, cap))
        portable_path.unlink()
        if sum(item["size_bytes"] for item in archives) > total_cap:
            raise ValueError("archives exceed total size limit")
    support = support_members(artifact_root, args.worktree.resolve())
    historical_artifacts = None
    if "main-532aac3f" in extra:
        old_members, old_run = historical_reference_members(artifact_root, args.worktree.resolve())
        old_rows = [{"path": arc, "sha256": sha256(src), "size_bytes": src.stat().st_size}
                    for src, arc in sorted(old_members, key=lambda item: item[1])]
        old_portable = {
            "format_version": 1,
            "label": "main-532aac3f",
            "revision": old_run["revision"],
            "profile": old_run["profile"],
            "original_run": {"path": "historical/main-532aac3f/gates/RUN.json",
                             "sha256": sha256(artifact_root / "gates/main-532aac3f/RUN.json"),
                             "preserved_verbatim": True},
            "executables": {"included": False,
                            "recorded_original_sha256": old_run.get("sha256", {}),
                            "rebuild_note": "Frozen executables are omitted; a rebuild is not the recorded binary unless its SHA-256 matches."},
            "artifacts": old_rows,
        }
        old_portable_path = staging / "main-532aac3f.RUN.portable.json"
        old_portable_path.write_text(json.dumps(old_portable, indent=2) + "\n")
        support.extend(old_members)
        support.append((old_portable_path, "historical/main-532aac3f/RUN.portable.json"))
        historical_artifacts = old_rows + [{"path": "historical/main-532aac3f/RUN.portable.json",
                                             "sha256": sha256(old_portable_path),
                                             "size_bytes": old_portable_path.stat().st_size}]
    readme_path = staging / "PORTABLE-EVIDENCE-README.md"
    readme_path.write_text("""# Frozen benchmark evidence package\n\nEach revision archive contains the original `RUN.json` and `BUILD` metadata unchanged, plus `RUN.portable.json` with extraction-relative paths and SHA-256 values for every archived member. The top-level `index.json` lists the archive hashes and member hashes.\n\nVerify integrity by checking each archive SHA-256 against `index.json`, extracting it, then checking every listed member's SHA-256. Recompute allocation medians from the archived raw allocation samples; do not infer them from timing summaries. The archived analyzer report preserves raw timing rows and its schema distinctions.\n\nFrozen executables are omitted. Their original SHA-256 identities remain recorded in `RUN.json` and `RUN.portable.json`; these hashes identify the binaries used for the measurements but do not make those executables rerunnable. A fresh build is a different binary unless its SHA-256 matches. `BUILD` metadata, cargo dependency-tree provenance, exact source revisions, commands, load-guard attempts, raw logs, Family output, and Criterion JSON are included where recorded.\n\nFor verification, compare `shasum -a 256 <label>.tar.gz` with that archive's `sha256` in `index.json`. After extraction, compare each member path and SHA-256 in `index.json` (or the label's `RUN.portable.json`). Recompute the allocation median from the archived raw samples with `statistics.median`; keep workloads/revisions separate.\n\nExtract all archives into one directory to restore the paths listed in each `RUN.portable.json`.\n""")
    support.append((readme_path, "PORTABLE-EVIDENCE-README.md"))
    archives.append(archive_gz(staging / "support-and-analysis.tar.gz", support, cap))
    readme_path.unlink()
    if "main-532aac3f" in extra:
        old_portable_path.unlink()
    if sum(item["size_bytes"] for item in archives) > total_cap:
        raise ValueError("archives exceed total size limit")
    index = {"format_version": 2, "labels": expected_labels, "max_archive_bytes": cap,
             "archives": archives, "label_artifacts": label_artifacts,
             "historical_reference_labels": (["main-532aac3f"] if historical_artifacts is not None else []),
             "historical_reference_artifacts": historical_artifacts,
             "portable_run_manifests": {label: f"gates/{label}/RUN.portable.json" for label in expected_labels},
             "remapping": {"extract_root": "<portable-root>", "gate_root": "<portable-root>/gates",
                           "build_metadata": "<portable-root>/build-metadata", "support": "<portable-root>/tools and analysis",
                           "original_run_paths_are_archival_only": True,
                           "executables_included": False,
                           "reproduction": "Checkout each exact revision in a clean worktree, use archived BUILD metadata/commands, and redirect --artifact-root/--worktree/--binary-root to local paths. The archived RUN.json is preserved verbatim for provenance; use RUN.portable.json for extracted artifact paths. Rebuilt executables are not the recorded binaries unless SHA-256 matches."}}
    total_archive_bytes = sum(item["size_bytes"] for item in archives)
    if total_archive_bytes > total_cap:
        raise ValueError(f"total archives exceed limit ({total_archive_bytes} bytes)")
    index_path = staging / "index.json"
    index_path.write_text(json.dumps(index, indent=2) + "\n")
    os.replace(staging, out)
    print(json.dumps({"output": str(out), "archive_count": len(archives), "index": str(out / "index.json")}, indent=2))

if __name__ == "__main__":
    main()
