# Prep0 findings against main 8a38e96f2

The guarded main-to-prep0 comparison is structurally valid and fails strict observed non-regression gates. The analyzer retains every measured delta; no timing tolerance is introduced.

At 4, 16, and 64 writers, prep0 create storage conflicts per commit exactly match the short-ID reservation retry rates (0.0029296875, 0.002685546875, and 0.00244140625). Main reports zero for both. This is direct counter evidence. The code explanation is that prep0 moves short-ID reservation ahead of the per-collection arrival guard; its old allocator reserves a range in a separate transaction before installing it locally, allowing concurrent range reservations to conflict. Step3 replaces that transaction loop with the engine allocator. Recovery must be established by the step3 measurement, not assumed or used to waive prep0's gate.

The create allocation median is 3005.675 versus main 2991.135 (+14.54 allocations/op, about 0.49%). Create Criterion medians rise: 4 fields 24.225 versus22.588 microseconds,16 fields81.845 versus77.405 microseconds, branchable14 fields30.568 versus29.817 microseconds. The benchmark has no KMS; heavy prepared-key work is absent. Read-only source inspection has not established the cause of the single-attempt allocation difference. Later schema-validation and immutable-input optimizations target repeated work; only later measurements can establish recovery.

These are observed median/point-estimate comparisons, not statistical significance claims. Main itself fails strict increasing-throughput-with-writers targets.
