# Frozen DefraLevel gate results

Structural validity and observed gates are separate. Strict comparisons use the measured medians/point estimates with no tolerance; they do not account for timing noise.

## main-8a38e96f2

Revision `8a38e96f213cd9edc55c89eed272ba8f83c76524`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 249.1 | 0 | — | 0 | — | 4.0232 | 6.8615 |
| creates | 4 | 251.27 | 0 | — | 0 | — | 15.971 | 20.22 |
| creates | 16 | 251.13 | 0 | — | 0 | — | 63.913 | 88.096 |
| creates | 64 | 247.02 | 0 | — | 0 | — | 253.97 | 518.89 |
| shared_updates | 1 | 256.07 | 0 | — | 0 | — | 3.9985 | 5.4397 |
| shared_updates | 4 | 248.06 | 0 | — | 0.029297 | — | 15.038 | 43.746 |
| shared_updates | 16 | 246.11 | 0 | — | 0.50635 | — | 22.897 | 941.12 |
| shared_updates | 64 | 242.43 | 0 | — | 1.8402 | — | 28.878 | 2866.3 |
| counters_indexes | 1 | 238.35 | 0 | — | 0 | — | 4.0415 | 9.2235 |
| counters_indexes | 4 | 233.95 | 0 | — | 0.026367 | — | 15.983 | 51.97 |
| counters_indexes | 16 | 240.9 | 0 | — | 0.54543 | — | 25.915 | 731.93 |
| counters_indexes | 64 | 232.5 | 0 | — | 1.8932 | — | 33.042 | 2973.4 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.029296875, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.5058622374206155, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.8050863541468969, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.0263671875, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.5449438202247191, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 1.8603756933938478, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `None`; legacy indicators zero `True`. Allocation samples `[2991.135, 2984.99, 2984.19, 2991.58, 3000.055]`, median `2991.135`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 249.09638704421474, "4": 251.2712581609755, "16": 251.12524182723934, "64": 247.0186023898854} |
| shared_updates | observed_fail | {"1": 256.07123030985036, "4": 248.0624211292012, "16": 246.10937735323873, "64": 242.4276841501726} |
| counters_indexes | observed_fail | {"1": 238.34776591280837, "4": 233.95166407830985, "16": 240.89833199371864, "64": 232.50476924839174} |

## step0-d6f58d624

Revision `d6f58d6249ca90701f8ceb9732d859e046e6fdc6`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 255.48 | 0 | — | 0 | — | 4.0254 | 4.2288 |
| creates | 4 | 249.2 | 0.0029297 | — | 0 | — | 15.986 | 20.972 |
| creates | 16 | 253.02 | 0.0026855 | — | 0 | — | 62.991 | 94.065 |
| creates | 64 | 244.8 | 0.0024414 | — | 0 | — | 256.99 | 486.32 |
| shared_updates | 1 | 255.96 | 0 | — | 0 | — | 3.9685 | 6.3902 |
| shared_updates | 4 | 250.54 | 0 | — | 0.036133 | — | 14.973 | 47.933 |
| shared_updates | 16 | 246.13 | 0 | — | 0.5453 | — | 25.856 | 796.9 |
| shared_updates | 64 | 240.42 | 0 | — | 1.7795 | — | 28.899 | 2956.4 |
| counters_indexes | 1 | 246.62 | 0 | — | 0 | — | 4.056 | 5.7076 |
| counters_indexes | 4 | 250.07 | 0 | — | 0.035156 | — | 14.997 | 54.403 |
| counters_indexes | 16 | 249.82 | 0 | — | 0.52734 | — | 25.948 | 748.76 |
| counters_indexes | 64 | 232.15 | 0 | — | 1.9157 | — | 33.954 | 2847.9 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0029296875}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.002685546875}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.00244140625}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.0361328125, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.545054945054945, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.741174979403004, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.03515625, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.52734375, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 1.8822379210293931, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_fail**; current-schema zero proof `None`; legacy indicators zero `False`. Allocation samples `[2997.085, 3007.035, 3005.675, 3018.64, 3000.925]`, median `3005.675`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 255.4794605990295, "4": 249.19628218527828, "16": 253.0219813619088, "64": 244.80023253631467} |
| shared_updates | observed_fail | {"1": 255.96004873175377, "4": 250.53537458357482, "16": 246.12715429159093, "64": 240.4170459472765} |
| counters_indexes | observed_fail | {"1": 246.6206171705029, "4": 250.06992519230963, "16": 249.81636132542823, "64": 232.15250918551772} |

## step1a-3162318e2

Revision `3162318e27754ccf5cb64ae4f04bd8675505edfa`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 252.42 | 0 | — | 0 | — | 4.0045 | 4.8878 |
| creates | 4 | 250.57 | 0.0029297 | — | 0 | — | 15.983 | 21.576 |
| creates | 16 | 254.34 | 0.0019531 | — | 0 | — | 62.973 | 101.97 |
| creates | 64 | 250.01 | 0.0028076 | — | 0 | — | 253.93 | 494 |
| shared_updates | 1 | 226.9 | 0 | — | 0 | — | 4.0669 | 11.075 |
| shared_updates | 4 | 241.24 | 0 | — | 0.053711 | — | 15.957 | 66.02 |
| shared_updates | 16 | 253 | 0 | — | 0.5265 | — | 22.025 | 819.2 |
| shared_updates | 64 | 242.31 | 0 | — | 1.8194 | — | 29.008 | 2888.1 |
| counters_indexes | 1 | 231.89 | 0 | — | 0 | — | 4.0521 | 11.825 |
| counters_indexes | 4 | 251.59 | 0 | — | 0.036133 | — | 15.062 | 39.245 |
| counters_indexes | 16 | 238.84 | 0 | — | 0.52675 | — | 26.111 | 813.89 |
| counters_indexes | 64 | 230.19 | 0 | — | 1.925 | — | 34.942 | 2965.4 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0029296875}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.001953125}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0028076171875}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.0537109375, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.5262515262515263, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.7809469480889903, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.0361328125, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.5260200342047398, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 1.8909435153045124, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_fail**; current-schema zero proof `None`; legacy indicators zero `False`. Allocation samples `[2996.065, 3010.64, 3001.04, 3008.48, 2997.925]`, median `3001.04`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 252.42008371521933, "4": 250.56669610132045, "16": 254.34413885410612, "64": 250.01096360410293} |
| shared_updates | observed_fail | {"1": 226.89774531019157, "4": 241.24498433978798, "16": 252.99745088856622, "64": 242.31316537409387} |
| counters_indexes | observed_fail | {"1": 231.88993041546607, "4": 251.59053775112642, "16": 238.84234406386187, "64": 230.18881904198813} |

## Historical #218 comparison (descriptive)

These are local historical measurements from DefraLevel plan §5.3. They are reported as context only: hardware and profile comparability are unknown, so they do not determine gate status.

| Run | Criterion ID | Earlier local | #218 reference | Measured median | Delta vs #218 |
|---|---|---:|---:|---:|---:|
| main-8a38e96f2 | document_create/4 | 36.800 µs | 34.600 µs | 22.588 µs | -12.012 µs |
| main-8a38e96f2 | document_create/16 | 127.700 µs | 122.500 µs | 77.405 µs | -45.095 µs |
| main-8a38e96f2 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 29.817 µs | -17.583 µs |
| main-8a38e96f2 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 8.561 ms | -5.439 ms |
| main-8a38e96f2 | document create allocations | — | 2997 alloc/op | 2991.135 alloc/op | -5.864999999999782 alloc/op |
| step0-d6f58d624 | document_create/4 | 36.800 µs | 34.600 µs | 24.225 µs | -10.375 µs |
| step0-d6f58d624 | document_create/16 | 127.700 µs | 122.500 µs | 81.845 µs | -40.655 µs |
| step0-d6f58d624 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 30.568 µs | -16.832 µs |
| step0-d6f58d624 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.005 ms | -4.995 ms |
| step0-d6f58d624 | document create allocations | — | 2997 alloc/op | 3005.675 alloc/op | 8.675000000000182 alloc/op |
| step1a-3162318e2 | document_create/4 | 36.800 µs | 34.600 µs | 23.014 µs | -11.586 µs |
| step1a-3162318e2 | document_create/16 | 127.700 µs | 122.500 µs | 76.954 µs | -45.546 µs |
| step1a-3162318e2 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 27.725 µs | -19.675 µs |
| step1a-3162318e2 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 8.960 ms | -5.040 ms |
| step1a-3162318e2 | document create allocations | — | 2997 alloc/op | 3001.04 alloc/op | 4.039999999999964 alloc/op |

## Main and immediate-predecessor comparisons

### main-8a38e96f2 → step0-d6f58d624

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 13 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 13 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 249.19628218527828, "delta": -2.074975975697214, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.2712581609755, "workload": "creates", "writers": 4}, {"candidate_median": 0.0029296875, "delta": 0.0029296875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.002685546875, "delta": 0.002685546875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 244.80023253631467, "delta": -2.218369853570721, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.0186023898854, "workload": "creates", "writers": 64}, {"candidate_median": 0.00244140625, "delta": 0.00244140625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 255.96004873175377, "delta": -0.11118157809659124, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.0361328125, "delta": 0.0068359375, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.029296875, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.5452991452991452, "delta": 0.03894838809347845, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 240.4170459472765, "delta": -2.0106382028961036, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03834210025983903, "delta": 0.0018392850513870782, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03515625, "delta": 0.0087890625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0263671875, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 232.15250918551772, "delta": -0.35226006287402356, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.9156679702283335, "delta": 0.022513658579316864, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 249.19628218527828, "delta": -2.074975975697214, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.2712581609755, "workload": "creates", "writers": 4}, {"candidate_median": 0.0029296875, "delta": 0.0029296875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.002685546875, "delta": 0.002685546875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 244.80023253631467, "delta": -2.218369853570721, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.0186023898854, "workload": "creates", "writers": 64}, {"candidate_median": 0.00244140625, "delta": 0.00244140625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 255.96004873175377, "delta": -0.11118157809659124, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.0361328125, "delta": 0.0068359375, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.029296875, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.5452991452991452, "delta": 0.03894838809347845, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 240.4170459472765, "delta": -2.0106382028961036, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03834210025983903, "delta": 0.0018392850513870782, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03515625, "delta": 0.0087890625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0263671875, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 232.15250918551772, "delta": -0.35226006287402356, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.9156679702283335, "delta": 0.022513658579316864, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → step1a-3162318e2

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 17 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 14 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_pass**.

Observed regressions vs main: `[{"candidate_median": 250.56669610132045, "delta": -0.7045620596550464, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.2712581609755, "workload": "creates", "writers": 4}, {"candidate_median": 0.0029296875, "delta": 0.0029296875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.001953125, "delta": 0.001953125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 0.0028076171875, "delta": 0.0028076171875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 226.89774531019157, "delta": -29.173484999658797, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 241.24498433978798, "delta": -6.817436789413222, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0624211292012, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0537109375, "delta": 0.0244140625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.029296875, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.5264957264957265, "delta": 0.02014496929005971, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 242.31316537409387, "delta": -0.11451877607873939, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03847372757812005, "delta": 0.0019709123696681, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 231.88993041546607, "delta": -6.457835497342302, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.34776591280837, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.0361328125, "delta": 0.009765625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0263671875, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 238.84234406386187, "delta": -2.0559879298567694, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.0004885197850512946, "delta": 0.0004885197850512946, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 230.18881904198813, "delta": -2.3159502064036133, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.9249605553802462, "delta": 0.031806243731229644, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 0.035912999494183105, "delta": 0.0016348604878072479, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03427813900637586, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 252.42008371521933, "delta": -3.0593768838101596, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 255.4794605990295, "workload": "creates", "writers": 1}, {"candidate_median": 0.0028076171875, "delta": 0.0003662109375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.00244140625, "workload": "creates", "writers": 64}, {"candidate_median": 226.89774531019157, "delta": -29.062303421562206, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 255.96004873175377, "workload": "shared_updates", "writers": 1}, {"candidate_median": 241.24498433978798, "delta": -9.290390243786845, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.53537458357482, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0537109375, "delta": 0.017578125, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0361328125, "workload": "shared_updates", "writers": 4}, {"candidate_median": 1.8194206756671103, "delta": 0.039903596004267294, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.779517079662843, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03847372757812005, "delta": 0.0001316273182810218, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03834210025983903, "workload": "shared_updates", "writers": 64}, {"candidate_median": 231.88993041546607, "delta": -14.730686755036828, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.6206171705029, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.0361328125, "delta": 0.0009765625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.03515625, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 238.84234406386187, "delta": -10.97401726156636, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 249.81636132542823, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.0004885197850512946, "delta": 0.0004885197850512946, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 230.18881904198813, "delta": -1.9636901435295897, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.15250918551772, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.9249605553802462, "delta": 0.00929258515191278, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.9156679702283335, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 0.035912999494183105, "delta": 0.002222147759167334, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03369085173501577, "workload": "counters_indexes", "writers": 64}]`

## Scope limits

The shared-updates workload includes same-field contention among writers in each parity group, so its aggregate conflict count cannot prove the separate disjoint-field target. The focused disjoint-update regression test must provide that evidence. Legacy HTTP retry metrics are not relabeled as current client conflicts.
