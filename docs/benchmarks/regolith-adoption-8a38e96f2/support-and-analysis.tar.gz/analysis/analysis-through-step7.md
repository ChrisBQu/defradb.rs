# Frozen DefraLevel gate results

Structural validity and observed gates are separate. Strict comparisons use the measured medians/point estimates with no tolerance; they do not account for timing noise.

## main-8a38e96f2

Revision `8a38e96f213cd9edc55c89eed272ba8f83c76524`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 249.1 | 0 | — | 0 | — | 4.0232 | 6.8615 |
| creates | 4 | 251.27 | 0 | — | 0 | — | 15.971 | 20.22 |
| creates | 16 | 251.13 | 0 | — | 0 | — | 63.913 | 88.096 |
| creates | 64 | 247.02 | 0 | — | 0 | — | 253.97 | 518.89 |
| shared_updates | 1 | 256.07 | 0 | — | 0 | — | 3.9985 | 5.4397 |
| shared_updates | 4 | 248.06 | 0 | — | 0.029297 | — | 15.038 | 43.746 |
| shared_updates | 16 | 246.11 | 0 | — | 0.50635 | — | 22.897 | 941.12 |
| shared_updates | 64 | 242.43 | 0 | — | 1.8402 | — | 28.878 | 2866.3 |
| counters_indexes | 1 | 238.35 | 0 | — | 0 | — | 4.0415 | 9.2235 |
| counters_indexes | 4 | 233.95 | 0 | — | 0.026367 | — | 15.983 | 51.97 |
| counters_indexes | 16 | 240.9 | 0 | — | 0.54543 | — | 25.915 | 731.93 |
| counters_indexes | 64 | 232.5 | 0 | — | 1.8932 | — | 33.042 | 2973.4 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.029296875, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.5058622374206155, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.8050863541468969, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.0263671875, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.5449438202247191, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 1.8603756933938478, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `None`; legacy indicators zero `True`. Allocation samples `[2991.135, 2984.99, 2984.19, 2991.58, 3000.055]`, median `2991.135`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 249.09638704421474, "4": 251.2712581609755, "16": 251.12524182723934, "64": 247.0186023898854} |
| shared_updates | observed_fail | {"1": 256.07123030985036, "4": 248.0624211292012, "16": 246.10937735323873, "64": 242.4276841501726} |
| counters_indexes | observed_fail | {"1": 238.34776591280837, "4": 233.95166407830985, "16": 240.89833199371864, "64": 232.50476924839174} |

## step0-d6f58d624

Revision `d6f58d6249ca90701f8ceb9732d859e046e6fdc6`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 255.48 | 0 | — | 0 | — | 4.0254 | 4.2288 |
| creates | 4 | 249.2 | 0.0029297 | — | 0 | — | 15.986 | 20.972 |
| creates | 16 | 253.02 | 0.0026855 | — | 0 | — | 62.991 | 94.065 |
| creates | 64 | 244.8 | 0.0024414 | — | 0 | — | 256.99 | 486.32 |
| shared_updates | 1 | 255.96 | 0 | — | 0 | — | 3.9685 | 6.3902 |
| shared_updates | 4 | 250.54 | 0 | — | 0.036133 | — | 14.973 | 47.933 |
| shared_updates | 16 | 246.13 | 0 | — | 0.5453 | — | 25.856 | 796.9 |
| shared_updates | 64 | 240.42 | 0 | — | 1.7795 | — | 28.899 | 2956.4 |
| counters_indexes | 1 | 246.62 | 0 | — | 0 | — | 4.056 | 5.7076 |
| counters_indexes | 4 | 250.07 | 0 | — | 0.035156 | — | 14.997 | 54.403 |
| counters_indexes | 16 | 249.82 | 0 | — | 0.52734 | — | 25.948 | 748.76 |
| counters_indexes | 64 | 232.15 | 0 | — | 1.9157 | — | 33.954 | 2847.9 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0029296875}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.002685546875}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.00244140625}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.0361328125, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.545054945054945, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.741174979403004, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.03515625, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.52734375, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 1.8822379210293931, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_fail**; current-schema zero proof `None`; legacy indicators zero `False`. Allocation samples `[2997.085, 3007.035, 3005.675, 3018.64, 3000.925]`, median `3005.675`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 255.4794605990295, "4": 249.19628218527828, "16": 253.0219813619088, "64": 244.80023253631467} |
| shared_updates | observed_fail | {"1": 255.96004873175377, "4": 250.53537458357482, "16": 246.12715429159093, "64": 240.4170459472765} |
| counters_indexes | observed_fail | {"1": 246.6206171705029, "4": 250.06992519230963, "16": 249.81636132542823, "64": 232.15250918551772} |

## step1a-3162318e2

Revision `3162318e27754ccf5cb64ae4f04bd8675505edfa`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 252.42 | 0 | — | 0 | — | 4.0045 | 4.8878 |
| creates | 4 | 250.57 | 0.0029297 | — | 0 | — | 15.983 | 21.576 |
| creates | 16 | 254.34 | 0.0019531 | — | 0 | — | 62.973 | 101.97 |
| creates | 64 | 250.01 | 0.0028076 | — | 0 | — | 253.93 | 494 |
| shared_updates | 1 | 226.9 | 0 | — | 0 | — | 4.0669 | 11.075 |
| shared_updates | 4 | 241.24 | 0 | — | 0.053711 | — | 15.957 | 66.02 |
| shared_updates | 16 | 253 | 0 | — | 0.5265 | — | 22.025 | 819.2 |
| shared_updates | 64 | 242.31 | 0 | — | 1.8194 | — | 29.008 | 2888.1 |
| counters_indexes | 1 | 231.89 | 0 | — | 0 | — | 4.0521 | 11.825 |
| counters_indexes | 4 | 251.59 | 0 | — | 0.036133 | — | 15.062 | 39.245 |
| counters_indexes | 16 | 238.84 | 0 | — | 0.52675 | — | 26.111 | 813.89 |
| counters_indexes | 64 | 230.19 | 0 | — | 1.925 | — | 34.942 | 2965.4 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0029296875}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.001953125}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0028076171875}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.0537109375, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.5262515262515263, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.7809469480889903, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.0361328125, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.5260200342047398, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 1.8909435153045124, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_fail**; current-schema zero proof `None`; legacy indicators zero `False`. Allocation samples `[2996.065, 3010.64, 3001.04, 3008.48, 2997.925]`, median `3001.04`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 252.42008371521933, "4": 250.56669610132045, "16": 254.34413885410612, "64": 250.01096360410293} |
| shared_updates | observed_fail | {"1": 226.89774531019157, "4": 241.24498433978798, "16": 252.99745088856622, "64": 242.31316537409387} |
| counters_indexes | observed_fail | {"1": 231.88993041546607, "4": 251.59053775112642, "16": 238.84234406386187, "64": 230.18881904198813} |

## step1b-1cf6a0b23

Revision `1cf6a0b236bf8f2fd357503a7d0762d6f1ea760b`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 251.73 | 0 | — | 0 | — | 4.0492 | 4.8664 |
| creates | 4 | 244.38 | 0.0029297 | — | 0 | — | 16.002 | 23.721 |
| creates | 16 | 254.85 | 0.001709 | — | 0 | — | 62.015 | 108.25 |
| creates | 64 | 240.66 | 0.0026245 | — | 0 | — | 256.75 | 505.44 |
| shared_updates | 1 | 239.69 | 0 | — | 0 | — | 4.0722 | 6.0795 |
| shared_updates | 4 | 242.74 | 0 | — | 0.02832 | — | 15.079 | 48.167 |
| shared_updates | 16 | 234.66 | 0 | — | 0.52369 | — | 24.864 | 818.77 |
| shared_updates | 64 | 210.32 | 0 | — | 1.9612 | — | 29.126 | 3116.9 |
| counters_indexes | 1 | 228.42 | 0 | — | 0 | — | 4.1057 | 7.3182 |
| counters_indexes | 4 | 231.94 | 0 | — | 0.045898 | — | 14.936 | 100.59 |
| counters_indexes | 16 | 188.84 | 0 | — | 0.59438 | — | 32.949 | 980.94 |
| counters_indexes | 64 | 150.69 | 0 | — | 2.3266 | — | 43.02 | 3994.9 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0029296875}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.001708984375}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.00262451171875}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.0283203125, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.5232046897899365, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.9215736040609137, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.0458984375, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.5941391941391941, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 2.272516726711271, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_fail**; current-schema zero proof `None`; legacy indicators zero `False`. Allocation samples `[3010.98, 2999.825, 3011.155, 3015.955, 2998.13]`, median `3010.98`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 251.7329379028434, "4": 244.38281727114045, "16": 254.85067785350046, "64": 240.65731895096167} |
| shared_updates | observed_fail | {"1": 239.68997607147816, "4": 242.74220224010872, "16": 234.65946148070373, "64": 210.31595967703555} |
| counters_indexes | observed_fail | {"1": 228.4241934745709, "4": 231.93979757929824, "16": 188.8390985566185, "64": 150.69330036646792} |

## step1-45c81aed5

Revision `45c81aed5c73f431e00549acb78c7f7582c725a1`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 254.31 | 0 | — | 0 | — | 4.048 | 8.7086 |
| creates | 4 | 274.02 | 0.0039062 | — | 0 | — | 14.058 | 19.087 |
| creates | 16 | 258.94 | 0.001709 | — | 0 | — | 59.995 | 78.987 |
| creates | 64 | 251.69 | 0.0027466 | — | 0 | — | 247.23 | 500.11 |
| shared_updates | 1 | 249.72 | 0 | — | 0 | — | 4.0447 | 6.8505 |
| shared_updates | 4 | 260.3 | 0 | — | 0.019531 | — | 14.983 | 38.902 |
| shared_updates | 16 | 246.56 | 0 | — | 0.50427 | — | 23.138 | 803.79 |
| shared_updates | 64 | 252.45 | 0 | — | 1.7663 | — | 25.269 | 2899.9 |
| counters_indexes | 1 | 246.83 | 0 | — | 0 | — | 4.065 | 6.9293 |
| counters_indexes | 4 | 249.48 | 0 | — | 0.021484 | — | 15.04 | 38.692 |
| counters_indexes | 16 | 259.29 | 0 | — | 0.53418 | — | 23.09 | 690.15 |
| counters_indexes | 64 | 228.33 | 0 | — | 1.8296 | — | 30.969 | 2944.7 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.00390625}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.001708984375}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.00274658203125}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.01953125, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.504029304029304, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.7207580881883735, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.021484375, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.5341796875, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 1.7901978189196044, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_fail**; current-schema zero proof `None`; legacy indicators zero `False`. Allocation samples `[3021.82, 3027.18, 3023.63, 3037.565, 3024.445]`, median `3024.445`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 254.30599377243763, "4": 274.0159186770333, "16": 258.94062481516164, "64": 251.6863344795961} |
| shared_updates | observed_fail | {"1": 249.72367417001993, "4": 260.29788411056495, "16": 246.56229429857584, "64": 252.44560888363145} |
| counters_indexes | observed_fail | {"1": 246.8251193430305, "4": 249.47816264128846, "16": 259.2938803357572, "64": 228.33121933930514} |

## step2-23c8fde54

Revision `23c8fde54a085ce99b6c10aa92c1ce2d52ac9cc0`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 245.99 | 0 | — | 0 | — | 4.0257 | 7.9767 |
| creates | 4 | 265.29 | 0.0029297 | — | 0 | — | 15.112 | 20.078 |
| creates | 16 | 263.23 | 0.0019531 | — | 0 | — | 59.063 | 80.005 |
| creates | 64 | 258.11 | 0.0079956 | — | 0 | — | 236.03 | 537.08 |
| shared_updates | 1 | 260.9 | 0 | — | 0 | — | 4.0112 | 5.1261 |
| shared_updates | 4 | 254.59 | 0 | — | 0.0039062 | — | 15.091 | 36.549 |
| shared_updates | 16 | 253.89 | 0 | — | 0.51307 | — | 23.281 | 891.91 |
| shared_updates | 64 | 247.11 | 0 | — | 1.6564 | — | 24.289 | 3032.2 |
| counters_indexes | 1 | 251.77 | 0 | — | 0 | — | 4.0667 | 5.129 |
| counters_indexes | 4 | 266.52 | 0 | — | 0.018555 | — | 14.937 | 35.238 |
| counters_indexes | 16 | 260.9 | 0 | — | 0.51355 | — | 25.257 | 728.02 |
| counters_indexes | 64 | 238.55 | 0 | — | 1.7372 | — | 25.938 | 2958.5 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0029296875}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.001953125}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.00799560546875}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.00390625, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.5123381382848766, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.6128908986688746, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.0185546875, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.5133089133089133, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 1.6922831632653061, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_fail**; current-schema zero proof `None`; legacy indicators zero `False`. Allocation samples `[3058.405, 3050.96, 3046.76, 3056.8, 3057.115]`, median `3056.8`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 245.99465922532823, "4": 265.2876688249241, "16": 263.23245567491756, "64": 258.11370811424354} |
| shared_updates | observed_fail | {"1": 260.89653885326544, "4": 254.5932476831558, "16": 253.89001193283056, "64": 247.11455164746565} |
| counters_indexes | observed_fail | {"1": 251.76851622529233, "4": 266.5207801322676, "16": 260.8957025707441, "64": 238.55090140359042} |

## step3-711555a37

Revision `711555a37a37b4c017e1753ea28f96beaaa757f2`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 256.33 | 0 | — | 0 | — | 3.9825 | 4.1972 |
| creates | 4 | 259.5 | 0 | — | 0 | — | 15.946 | 20.71 |
| creates | 16 | 260.79 | 0 | — | 0 | — | 59.223 | 73.977 |
| creates | 64 | 259.35 | 0 | — | 0 | — | 240.05 | 515.35 |
| shared_updates | 1 | 235.74 | 0 | — | 0 | — | 4.0572 | 8.1644 |
| shared_updates | 4 | 244.5 | 0 | — | 0.020508 | — | 14.952 | 37.101 |
| shared_updates | 16 | 226.85 | 0 | — | 0.59951 | — | 29.135 | 729.17 |
| shared_updates | 64 | 210.88 | 0 | — | 2.0168 | — | 33.985 | 3043.8 |
| counters_indexes | 1 | 234.23 | 0 | — | 0 | — | 4.0639 | 8.2178 |
| counters_indexes | 4 | 242.37 | 0 | — | 0.019531 | — | 15.072 | 38.131 |
| counters_indexes | 16 | 225.55 | 0 | — | 0.59155 | — | 30.048 | 708.91 |
| counters_indexes | 64 | 202.24 | 0 | — | 2.308 | — | 44.85 | 2743.2 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.0205078125, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.5992673992673992, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.9675952609670189, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.01953125, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.591552734375, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 2.272336661190446, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `None`; legacy indicators zero `True`. Allocation samples `[2983.88, 2983.84, 2983.95, 2983.855, 2983.805]`, median `2983.855`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 256.3281962142278, "4": 259.5022368032249, "16": 260.79330557082693, "64": 259.34702942821855} |
| shared_updates | observed_fail | {"1": 235.74092578730622, "4": 244.49959480877698, "16": 226.84551517218785, "64": 210.88154382059258} |
| counters_indexes | observed_fail | {"1": 234.2276250190955, "4": 242.37102769616646, "16": 225.55121038772353, "64": 202.23570296504136} |

## step4-965fb4e6e

Revision `965fb4e6e65d3a0874b0e5964eee4fde2509ede3`; schema `legacy-http-retry-conflicts`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 251.33 | 0 | — | 0 | — | 4.0326 | 4.8895 |
| creates | 4 | 250.12 | 0 | — | 0 | — | 15.98 | 19.684 |
| creates | 16 | 261.32 | 0 | — | 0 | — | 59.12 | 76.813 |
| creates | 64 | 261.39 | 0 | — | 0 | — | 237.97 | 504.3 |
| shared_updates | 1 | 230.81 | 0 | — | 0 | — | 4.0666 | 8.374 |
| shared_updates | 4 | 265.77 | 0 | — | 0.023438 | — | 14.018 | 38.933 |
| shared_updates | 16 | 237.42 | 0 | — | 0.58862 | — | 28.836 | 711.86 |
| shared_updates | 64 | 209.6 | 0 | — | 2.008 | — | 34.057 | 3014.7 |
| counters_indexes | 1 | 234.36 | 0 | — | 0 | — | 4.0681 | 8.2471 |
| counters_indexes | 4 | 237.37 | 0 | — | 0.025391 | — | 15.031 | 40.139 |
| counters_indexes | 16 | 227.83 | 0 | — | 0.60611 | — | 29.811 | 652.98 |
| counters_indexes | 64 | 201.44 | 0 | — | 2.3585 | — | 45.779 | 2710.1 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=4: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=16: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- creates|writers=64: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=4: {"HTTP retries": 0.0234375, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=16: {"HTTP retries": 0.588623046875, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- shared_updates|writers=64: {"HTTP retries": 1.9562175001604931, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=1: {"HTTP retries": 0.0, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=4: {"HTTP retries": 0.025390625, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=16: {"HTTP retries": 0.6058608058608058, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}
- counters_indexes|writers=64: {"HTTP retries": 2.326995718962478, "embedded retries": 0.0, "merge retries": 0.0, "push marker retries": 0.0, "short ID reservation retries": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `None`; legacy indicators zero `True`. Allocation samples `[2985.875, 2985.89, 2985.895, 2985.835, 2985.87]`, median `2985.875`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_fail | {"1": 251.33331637095253, "4": 250.11782033190914, "16": 261.3228448650005, "64": 261.3948748772237} |
| shared_updates | observed_fail | {"1": 230.81343591157278, "4": 265.7664893366845, "16": 237.4180786933737, "64": 209.60295406274767} |
| counters_indexes | observed_fail | {"1": 234.35894360875238, "4": 237.36982871269143, "16": 227.83195326968817, "64": 201.44078107052854} |

## step5-c2502fc5c

Revision `c2502fc5c1afd9e5f8013f11e3f0b35836548b6d`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 245.89 | 0 | 0 | — | 0 | 4.0659 | 6.613 |
| creates | 4 | 534.76 | 0 | 0 | — | 0 | 7.3123 | 11.016 |
| creates | 16 | 2090.8 | 0 | 0 | — | 0 | 7.7938 | 10.449 |
| creates | 64 | 7509.3 | 0 | 0 | — | 0 | 8.1242 | 15.688 |
| shared_updates | 1 | 251.69 | 0 | 0 | — | 0 | 4.0472 | 4.2388 |
| shared_updates | 4 | 244.93 | 0.0068359 | 0 | — | 0 | 16.005 | 22.041 |
| shared_updates | 16 | 171.58 | 1.1129 | 0 | — | 32 | 53.096 | 216.19 |
| shared_updates | 64 | 57.949 | 4.0394 | 0 | — | 8583 | 521.19 | 929.01 |
| counters_indexes | 1 | 247.84 | 0 | 0 | — | 0 | 4.068 | 4.9752 |
| counters_indexes | 4 | 228.42 | 0.0058594 | 0 | — | 0 | 16.93 | 24.039 |
| counters_indexes | 16 | 150.44 | 1.1122 | 0 | — | 33 | 65.807 | 269.97 |
| counters_indexes | 64 | 39.871 | 4.0404 | 0 | — | 8583 | 750.87 | 1388.3 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0068359375, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.129866929521932, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 6.239810305049987, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.005859375, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.1273666092943202, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 6.241056545710989, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3414.545, 3414.51, 3414.57, 3414.59, 3414.525]`, median `3414.545`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 245.89162070936268, "4": 534.7554136968278, "16": 2090.8495209096523, "64": 7509.313022831823} |
| shared_updates | observed_fail | {"1": 251.68912133283752, "4": 244.92746706628915, "16": 171.58366361244006, "64": 57.94885667656348} |
| counters_indexes | observed_fail | {"1": 247.83991203758785, "4": 228.41808126525325, "16": 150.44182148474127, "64": 39.87139103998394} |

## forcedread-d230f33fb

Revision `d230f33fb42881be8ae82322ae39dae74e869c68`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 248.08 | 0 | 0 | — | 0 | 4.0681 | 5.1542 |
| creates | 4 | 526.2 | 0 | 0 | — | 0 | 7.7618 | 10.053 |
| creates | 16 | 2015.8 | 0 | 0 | — | 0 | 7.9091 | 11.931 |
| creates | 64 | 7417.3 | 0 | 0 | — | 0 | 8.2409 | 16.364 |
| shared_updates | 1 | 247.14 | 0 | 0 | — | 0 | 4.0651 | 5.7052 |
| shared_updates | 4 | 248.01 | 0.0058594 | 0 | — | 0 | 15.999 | 20.856 |
| shared_updates | 16 | 167.07 | 1.1134 | 0 | — | 30 | 49.877 | 220.29 |
| shared_updates | 64 | 56.929 | 4.0324 | 0 | — | 8587 | 525.63 | 942.43 |
| counters_indexes | 1 | 249.28 | 0 | 0 | — | 0 | 4.064 | 4.7669 |
| counters_indexes | 4 | 224.51 | 0.0068359 | 0 | — | 0 | 16.072 | 24.027 |
| counters_indexes | 16 | 147.22 | 1.1125 | 0 | — | 32 | 66.309 | 274.19 |
| counters_indexes | 64 | 39.096 | 4.0406 | 0 | — | 8583 | 772.24 | 1418.8 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.005859375, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.1276438760452534, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 6.232376313765701, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0068359375, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.1281988188976377, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 6.241122932957313, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3414.605, 3414.575, 3414.5, 3414.565, 3414.535]`, median `3414.565`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 248.08008448413793, "4": 526.1990877331635, "16": 2015.7751879162251, "64": 7417.273926995713} |
| shared_updates | observed_fail | {"1": 247.13519864094945, "4": 248.01169069951013, "16": 167.0706695421499, "64": 56.92926752487318} |
| counters_indexes | observed_fail | {"1": 249.28007379126424, "4": 224.512791910444, "16": 147.21510649345393, "64": 39.09562320859603} |

## arrival-bafceb60c

Revision `bafceb60c0d8c0f59482a212a719e7ac2f14fa6a`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 251.99 | 0 | 0 | — | 0 | 4.0377 | 4.6958 |
| creates | 4 | 573.65 | 0 | 0 | — | 0 | 6.9179 | 8.9657 |
| creates | 16 | 2061.5 | 0 | 0 | — | 0 | 7.8039 | 9.6493 |
| creates | 64 | 7295.1 | 0 | 0 | — | 0 | 8.185 | 18.213 |
| shared_updates | 1 | 250.5 | 0 | 0 | — | 0 | 4.0562 | 5.3563 |
| shared_updates | 4 | 240 | 0.0068359 | 0 | — | 0 | 16.002 | 22.018 |
| shared_updates | 16 | 165.93 | 1.1129 | 0 | — | 30 | 47.985 | 225.51 |
| shared_updates | 64 | 56.705 | 4.039 | 0 | — | 8583 | 530.56 | 944.03 |
| counters_indexes | 1 | 239.67 | 0 | 0 | — | 0 | 4.0808 | 6.7857 |
| counters_indexes | 4 | 230.9 | 0.0058594 | 0 | — | 0 | 16.11 | 20.935 |
| counters_indexes | 16 | 147.69 | 1.1122 | 0 | — | 33 | 65.062 | 272.17 |
| counters_indexes | 64 | 39.413 | 4.0405 | 0 | — | 8583 | 773.07 | 1410.7 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0068359375, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.1276438760452534, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 6.240225612101013, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.005859375, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.1284764952005908, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 6.241122932957313, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3413.695, 3413.51, 3413.55, 3413.43, 3413.66]`, median `3413.55`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 251.98917250561178, "4": 573.651283202124, "16": 2061.488663563559, "64": 7295.108372477084} |
| shared_updates | observed_fail | {"1": 250.49880623717527, "4": 239.99882346201767, "16": 165.93232106229888, "64": 56.70537528673231} |
| counters_indexes | observed_fail | {"1": 239.67109830323741, "4": 230.90159115161362, "16": 147.69155447870608, "64": 39.41299207150431} |

## acpcounter-a4487cef0

Revision `a4487cef0752f822006e128618be3a99778a8878`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 250.75 | 0 | 0 | — | 0 | 4.0602 | 6.1971 |
| creates | 4 | 558.65 | 0 | 0 | — | 0 | 7.142 | 8.808 |
| creates | 16 | 2025.8 | 0 | 0 | — | 0 | 7.9119 | 10.657 |
| creates | 64 | 7116.2 | 0 | 0 | — | 0 | 8.2101 | 15.957 |
| shared_updates | 1 | 247.83 | 0 | 0 | — | 0 | 4.0568 | 5.0506 |
| shared_updates | 4 | 234.48 | 0.0078125 | 0 | — | 0 | 16.007 | 25.384 |
| shared_updates | 16 | 165.76 | 1.1125 | 0 | — | 30 | 57.966 | 226.07 |
| shared_updates | 64 | 57.158 | 4.0345 | 0 | — | 8582 | 531.28 | 935.7 |
| counters_indexes | 1 | 244.99 | 0 | 0 | — | 0 | 4.0785 | 5.1307 |
| counters_indexes | 4 | 220.89 | 0.0058594 | 0 | — | 0 | 16.98 | 25.274 |
| counters_indexes | 16 | 149.42 | 1.1125 | 0 | — | 32 | 65.844 | 273.36 |
| counters_indexes | 64 | 39.58 | 4.0377 | 0 | — | 8582 | 750.56 | 1404.1 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0078125, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.1276438760452534, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 6.233884403434576, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.005859375, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.1281988188976377, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 6.2378510065393, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3413.565, 3413.685, 3413.525, 3413.575, 3413.485]`, median `3413.565`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 250.74844984076003, "4": 558.6498077902324, "16": 2025.7589814635774, "64": 7116.247534570308} |
| shared_updates | observed_fail | {"1": 247.8282155180456, "4": 234.4774604533956, "16": 165.76179492049374, "64": 57.15769860030865} |
| counters_indexes | observed_fail | {"1": 244.99241930771055, "4": 220.88945935231177, "16": 149.42365378646775, "64": 39.58027843195142} |

## docqueue-1ceaefaca

Revision `1ceaefaca54f684086cf218f5cc69470c59cbe5b`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 251.74 | 0 | 0 | — | 0 | 4.032 | 5.0207 |
| creates | 4 | 549.29 | 0 | 0 | — | 0 | 7.1616 | 9.3689 |
| creates | 16 | 2020.8 | 0 | 0 | — | 0 | 7.8986 | 10.121 |
| creates | 64 | 7317.1 | 0 | 0 | — | 0 | 8.3182 | 17.295 |
| shared_updates | 1 | 244.06 | 0 | 0 | — | 0 | 4.0663 | 5.1059 |
| shared_updates | 4 | 550.89 | 0.011719 | 0 | — | 0 | 6.9172 | 13.019 |
| shared_updates | 16 | 930.78 | 0.92407 | 0 | — | 316 | 13.917 | 41.026 |
| shared_updates | 64 | 463.82 | 2.3022 | 0 | — | 8649 | 44.477 | 200.94 |
| counters_indexes | 1 | 245.43 | 0 | 0 | — | 0 | 4.0693 | 5.6217 |
| counters_indexes | 4 | 523.96 | 0.0078125 | 0 | — | 0 | 7.7523 | 11.01 |
| counters_indexes | 16 | 787.81 | 0.86969 | 0 | — | 347 | 13.06 | 48.06 |
| counters_indexes | 64 | 279.07 | 2.2766 | 0 | — | 8478 | 79.027 | 298.36 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.01171875, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0912698412698412, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.541305753070459, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0078125, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0546184738955824, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.421325575512269, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3413.57, 3413.545, 3413.5, 3413.55, 3413.53]`, median `3413.545`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 251.7385902896189, "4": 549.2886179469616, "16": 2020.7667578934813, "64": 7317.136892207605} |
| shared_updates | observed_fail | {"1": 244.0611392221028, "4": 550.890011500636, "16": 930.7758829566563, "64": 463.82123070126687} |
| counters_indexes | observed_fail | {"1": 245.43208302397508, "4": 523.9550048481905, "16": 787.8126622251425, "64": 279.0661967584117} |

## collectionlock-b33f571c7

Revision `b33f571c7b1f05e647d1ad6ab993c76abd1001b0`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 248.13 | 0 | 0 | — | 0 | 4.0744 | 5.0835 |
| creates | 4 | 564.18 | 0 | 0 | — | 0 | 7.1544 | 10.889 |
| creates | 16 | 2045.7 | 0 | 0 | — | 0 | 7.829 | 10.768 |
| creates | 64 | 7368.8 | 0 | 0 | — | 0 | 8.3658 | 15.724 |
| shared_updates | 1 | 248.08 | 0 | 0 | — | 0 | 4.0617 | 5.0293 |
| shared_updates | 4 | 524.06 | 0.0087891 | 0 | — | 0 | 7.7315 | 12.359 |
| shared_updates | 16 | 925.29 | 0.89873 | 0 | — | 324 | 13.966 | 41.056 |
| shared_updates | 64 | 468.27 | 2.2373 | 0 | — | 8521 | 43.875 | 207.86 |
| counters_indexes | 1 | 238.36 | 0 | 0 | — | 0 | 4.106 | 5.178 |
| counters_indexes | 4 | 547.24 | 0.0097656 | 0 | — | 0 | 7.2272 | 9.7618 |
| counters_indexes | 16 | 787.79 | 0.89575 | 0 | — | 314 | 13.98 | 49.058 |
| counters_indexes | 64 | 271.93 | 2.2904 | 0 | — | 8471 | 81.7 | 301.89 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0087890625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0705196182396606, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.404680147526389, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.009765625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.060021152829191, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.416824077572095, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3593.41, 3593.545, 3593.55, 3593.62, 3593.52]`, median `3593.545`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 248.1327244341083, "4": 564.1844009034055, "16": 2045.659509813335, "64": 7368.844358293191} |
| shared_updates | observed_fail | {"1": 248.0754668672238, "4": 524.0613929692462, "16": 925.2889564604205, "64": 468.2705486090866} |
| counters_indexes | observed_fail | {"1": 238.3618211401796, "4": 547.2352950638976, "16": 787.7939959244292, "64": 271.92548064588505} |

## peergeneration-6262270d1

Revision `6262270d1aaa5a92fafefc15a341dd4b0acd49c8`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 251.51 | 0 | 0 | — | 0 | 4.0355 | 4.1997 |
| creates | 4 | 572.03 | 0 | 0 | — | 0 | 6.8424 | 9.8232 |
| creates | 16 | 2043.4 | 0 | 0 | — | 0 | 7.8522 | 11.698 |
| creates | 64 | 7453.3 | 0 | 0 | — | 0 | 8.2257 | 15.947 |
| shared_updates | 1 | 248.06 | 0 | 0 | — | 0 | 4.0599 | 5.1137 |
| shared_updates | 4 | 541.86 | 0.0087891 | 0 | — | 0 | 7.2354 | 9.242 |
| shared_updates | 16 | 921.77 | 0.87667 | 0 | — | 358 | 12.068 | 40.999 |
| shared_updates | 64 | 466.84 | 2.2445 | 0 | — | 8585 | 44.085 | 205.8 |
| counters_indexes | 1 | 247.63 | 0 | 0 | — | 0 | 4.0662 | 5.1561 |
| counters_indexes | 4 | 563.29 | 0.0087891 | 0 | — | 0 | 7.0873 | 11.056 |
| counters_indexes | 16 | 797.94 | 0.85764 | 0 | — | 345 | 13.876 | 49 |
| counters_indexes | 64 | 270.32 | 2.2771 | 0 | — | 8469 | 80.17 | 322.17 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0087890625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0682182985553772, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.44069752532376, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0087890625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0529569892473118, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.405053695514845, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3593.585, 3593.63, 3593.5, 3593.605, 3593.54]`, median `3593.585`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 251.5065317390844, "4": 572.0268799430605, "16": 2043.4042561152307, "64": 7453.3483343311145} |
| shared_updates | observed_fail | {"1": 248.0596719168593, "4": 541.858622795731, "16": 921.7683057193283, "64": 466.8423555851247} |
| counters_indexes | observed_fail | {"1": 247.628974814071, "4": 563.2917120021147, "16": 797.9367471537978, "64": 270.31636564649716} |

## acpengine-d7d8d0c17

Revision `d7d8d0c1764a0091242e368d72ae23c946130781`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 250.5 | 0 | 0 | — | 0 | 4.0518 | 4.1915 |
| creates | 4 | 574.39 | 0 | 0 | — | 0 | 6.8272 | 11.282 |
| creates | 16 | 2072.9 | 0 | 0 | — | 0 | 7.8052 | 9.3567 |
| creates | 64 | 7362.9 | 0 | 0 | — | 0 | 8.1914 | 16.143 |
| shared_updates | 1 | 247.57 | 0 | 0 | — | 0 | 4.0511 | 5.098 |
| shared_updates | 4 | 501.77 | 0.0097656 | 0 | — | 0 | 7.1062 | 11.873 |
| shared_updates | 16 | 933.64 | 0.90856 | 0 | — | 319 | 13.011 | 40.013 |
| shared_updates | 64 | 466.5 | 2.2667 | 0 | — | 8565 | 44.325 | 207.35 |
| counters_indexes | 1 | 236.34 | 0 | 0 | — | 0 | 4.0956 | 6.3733 |
| counters_indexes | 4 | 540.05 | 0.0097656 | 0 | — | 0 | 7.6585 | 12.174 |
| counters_indexes | 16 | 780.42 | 0.88406 | 0 | — | 344 | 13.904 | 50.715 |
| counters_indexes | 64 | 287.93 | 2.2595 | 0 | — | 8407 | 75.47 | 293.3 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.009765625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0778537611783272, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.457475380483438, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.009765625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0505529225908372, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.38799047260875, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3593.555, 3593.54, 3593.54, 3593.47, 3593.57]`, median `3593.54`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 250.50336130743182, "4": 574.3938959429925, "16": 2072.8675000973567, "64": 7362.91422922834} |
| shared_updates | observed_fail | {"1": 247.57203925179635, "4": 501.77182048966114, "16": 933.6360625428634, "64": 466.50209276669904} |
| counters_indexes | observed_fail | {"1": 236.3351799798054, "4": 540.05169141682, "16": 780.4199223341137, "64": 287.9349442381543} |

## deferredacp-5ae8448a4

Revision `5ae8448a4dc3b27dc60d1034dfdcf46c9f697fea`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 250.25 | 0 | 0 | — | 0 | 4.0601 | 4.7823 |
| creates | 4 | 566.26 | 0 | 0 | — | 0 | 7.0686 | 8.7622 |
| creates | 16 | 2034.8 | 0 | 0 | — | 0 | 7.8718 | 10.269 |
| creates | 64 | 7449.9 | 0 | 0 | — | 0 | 8.1964 | 15.064 |
| shared_updates | 1 | 246.84 | 0 | 0 | — | 0 | 4.0811 | 5.2119 |
| shared_updates | 4 | 557.71 | 0.0097656 | 0 | — | 0 | 6.9829 | 11.915 |
| shared_updates | 16 | 875.67 | 0.88122 | 0 | — | 358 | 12.108 | 40.203 |
| shared_updates | 64 | 460.29 | 2.2708 | 0 | — | 8560 | 44.893 | 204.37 |
| counters_indexes | 1 | 240.38 | 0 | 0 | — | 0 | 4.0871 | 5.9042 |
| counters_indexes | 4 | 531.77 | 0.0087891 | 0 | — | 0 | 7.6446 | 11.85 |
| counters_indexes | 16 | 783.21 | 0.91184 | 0 | — | 296 | 14.864 | 48.133 |
| counters_indexes | 64 | 279.21 | 2.2824 | 0 | — | 8469 | 76.857 | 309.17 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.009765625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0727661851257357, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.458972392638037, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0087890625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0676315789473685, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.42236260265319, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3593.56, 3593.49, 3593.535, 3593.445, 3593.615]`, median `3593.535`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 250.25111673143405, "4": 566.2633406438023, "16": 2034.7817616157972, "64": 7449.942996795718} |
| shared_updates | observed_fail | {"1": 246.83866537858796, "4": 557.7071319999241, "16": 875.669838404087, "64": 460.2885680248134} |
| counters_indexes | observed_fail | {"1": 240.3796873030791, "4": 531.7714049459408, "16": 783.209804844081, "64": 279.20765629371715} |

## headcache-5af484fb3

Revision `5af484fb3ffd85108423fcdd2313480625fd2aaa`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 249.51 | 0 | 0 | — | 0 | 4.0412 | 4.6836 |
| creates | 4 | 579.78 | 0 | 0 | — | 0 | 6.8971 | 8.2922 |
| creates | 16 | 2034.8 | 0 | 0 | — | 0 | 7.8754 | 11.919 |
| creates | 64 | 7420 | 0 | 0 | — | 0 | 8.3072 | 16.05 |
| shared_updates | 1 | 250.95 | 0 | 0 | — | 0 | 4.0561 | 4.1922 |
| shared_updates | 4 | 556.82 | 0.0097656 | 0 | — | 0 | 7.0863 | 9.2852 |
| shared_updates | 16 | 913.82 | 0.87731 | 0 | — | 344 | 12.045 | 40.13 |
| shared_updates | 64 | 456.02 | 2.2504 | 0 | — | 8541 | 44.239 | 208.98 |
| counters_indexes | 1 | 246.85 | 0 | 0 | — | 0 | 4.0825 | 6.0358 |
| counters_indexes | 4 | 542.64 | 0.010742 | 0 | — | 0 | 7.2059 | 10.193 |
| counters_indexes | 16 | 744.6 | 0.86663 | 0 | — | 332 | 13.987 | 49.917 |
| counters_indexes | 64 | 272.04 | 2.2963 | 0 | — | 8459 | 78.264 | 309.57 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.009765625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0670943597968459, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.427514981512177, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0107421875, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0464371497197757, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.431041009463723, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3593.465, 3593.605, 3593.6, 3593.53, 3593.575]`, median `3593.575`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 249.51072506257262, "4": 579.7833809821567, "16": 2034.7640713314522, "64": 7419.991889302151} |
| shared_updates | observed_fail | {"1": 250.94975143824132, "4": 556.8152521859452, "16": 913.8161598585781, "64": 456.02309838789694} |
| counters_indexes | observed_fail | {"1": 246.85210340671642, "4": 542.6414236171888, "16": 744.599262942673, "64": 272.03643163903814} |

## step6-47a35b111

Revision `47a35b11180a503394f23d7c511d65cc650a5245`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 251.72 | 0 | 0 | — | 0 | 4.0452 | 4.192 |
| creates | 4 | 564.22 | 0 | 0 | — | 0 | 6.93 | 8.3814 |
| creates | 16 | 2062.6 | 0 | 0 | — | 0 | 7.8173 | 11.819 |
| creates | 64 | 7417.1 | 0 | 0 | — | 0 | 8.161 | 15.574 |
| shared_updates | 1 | 250.26 | 0 | 0 | — | 0 | 4.0489 | 4.4925 |
| shared_updates | 4 | 579.19 | 0.0019531 | 0 | — | 0 | 6.8606 | 11.8 |
| shared_updates | 16 | 1504.2 | 0.15641 | 0 | — | 18 | 8.899 | 25.188 |
| shared_updates | 64 | 490.66 | 1.4139 | 0 | — | 4770 | 57.293 | 278.84 |
| counters_indexes | 1 | 233.41 | 0 | 0 | — | 0 | 4.0995 | 7.1603 |
| counters_indexes | 4 | 548.51 | 0.0078125 | 0 | — | 0 | 7.1837 | 9.9245 |
| counters_indexes | 16 | 786.52 | 0.86775 | 0 | — | 335 | 12.985 | 48.011 |
| counters_indexes | 64 | 301.38 | 2.2654 | 0 | — | 8459 | 70.851 | 286.88 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.001953125, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.16474626133856338, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 2.2360692446817674, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0078125, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0467339352097715, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.403333754261902, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3133.545, 3133.64, 3133.52, 3133.605, 3133.37]`, median `3133.545`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 251.71837540099165, "4": 564.2222741659353, "16": 2062.5601275806234, "64": 7417.145630294404} |
| shared_updates | observed_fail | {"1": 250.26184011616647, "4": 579.186052702113, "16": 1504.23388738921, "64": 490.66394507314374} |
| counters_indexes | observed_fail | {"1": 233.41185016207973, "4": 548.5099538286122, "16": 786.5245132706592, "64": 301.38469391211237} |

## step7-11b71efcd

Revision `11b71efcdc6d6ceefc74984c6184c1e1e90aed90`; schema `request-conflicts-engine-exhaustions`; structurally valid: **True**; create coverage complete: **True**.

| Workload | Writers | Commits/s median | Storage conflicts/commit | Client conflicts/commit | Legacy HTTP conflicts/commit | Engine exhausted requests | p50 ms | p99 ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| creates | 1 | 249.51 | 0 | 0 | — | 0 | 4.0718 | 4.9875 |
| creates | 4 | 565.5 | 0 | 0 | — | 0 | 6.8886 | 10.746 |
| creates | 16 | 2101.6 | 0 | 0 | — | 0 | 7.7503 | 9.1303 |
| creates | 64 | 7400.4 | 0 | 0 | — | 0 | 8.1142 | 16.753 |
| shared_updates | 1 | 249.97 | 0 | 0 | — | 0 | 4.0418 | 4.2495 |
| shared_updates | 4 | 522.74 | 0.0019531 | 0 | — | 0 | 7.7683 | 10.452 |
| shared_updates | 16 | 1533.5 | 0.12794 | 0 | — | 16 | 8.8391 | 24.125 |
| shared_updates | 64 | 498.52 | 2.7034 | 0 | — | 4843 | 54.881 | 283.48 |
| counters_indexes | 1 | 249.81 | 0 | 0 | — | 0 | 4.0665 | 4.721 |
| counters_indexes | 4 | 551.36 | 0.0087891 | 0 | — | 0 | 7.1265 | 11.839 |
| counters_indexes | 16 | 765.7 | 1.1477 | 0 | — | 313 | 13.962 | 48.034 |
| counters_indexes | 64 | 297.69 | 5.4096 | 0 | — | 8408 | 70.094 | 290.89 |

Per-layer retry medians:

- creates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- creates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.001953125, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.12401960784313726, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- shared_updates|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 2.2837709037345117, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=1: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=4: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 0.0087890625, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=16: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 1.0571428571428572, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}
- counters_indexes|writers=64: {"HTTP retries (retired)": 0.0, "embedded retries (retired)": 0.0, "engine retries": 4.355441323971916, "merge retries (retired)": 0.0, "push marker retries": 0.0, "short ID reservation retries (retired)": 0.0}

Create-conflict gate: **observed_pass**; current-schema zero proof `True`; legacy indicators zero `None`. Allocation samples `[3133.545, 3133.555, 3133.525, 3133.51, 3133.52]`, median `3133.525`.

| Workload | Strict median throughput scaling | Rates by writers |
|---|---|---|
| creates | observed_pass | {"1": 249.51202197995846, "4": 565.503057147356, "16": 2101.579327834644, "64": 7400.386652586931} |
| shared_updates | observed_fail | {"1": 249.96780810088546, "4": 522.7413992636513, "16": 1533.5023491850968, "64": 498.5218462946329} |
| counters_indexes | observed_fail | {"1": 249.81169589573292, "4": 551.3649783088495, "16": 765.7023808897043, "64": 297.6917253935912} |

## Historical #218 comparison (descriptive)

These are local historical measurements from DefraLevel plan §5.3. They are reported as context only: hardware and profile comparability are unknown, so they do not determine gate status.

| Run | Criterion ID | Earlier local | #218 reference | Measured median | Delta vs #218 |
|---|---|---:|---:|---:|---:|
| main-8a38e96f2 | document_create/4 | 36.800 µs | 34.600 µs | 22.588 µs | -12.012 µs |
| main-8a38e96f2 | document_create/16 | 127.700 µs | 122.500 µs | 77.405 µs | -45.095 µs |
| main-8a38e96f2 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 29.817 µs | -17.583 µs |
| main-8a38e96f2 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 8.561 ms | -5.439 ms |
| main-8a38e96f2 | document create allocations | — | 2997 alloc/op | 2991.135 alloc/op | -5.864999999999782 alloc/op |
| step0-d6f58d624 | document_create/4 | 36.800 µs | 34.600 µs | 24.225 µs | -10.375 µs |
| step0-d6f58d624 | document_create/16 | 127.700 µs | 122.500 µs | 81.845 µs | -40.655 µs |
| step0-d6f58d624 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 30.568 µs | -16.832 µs |
| step0-d6f58d624 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.005 ms | -4.995 ms |
| step0-d6f58d624 | document create allocations | — | 2997 alloc/op | 3005.675 alloc/op | 8.675000000000182 alloc/op |
| step1a-3162318e2 | document_create/4 | 36.800 µs | 34.600 µs | 23.014 µs | -11.586 µs |
| step1a-3162318e2 | document_create/16 | 127.700 µs | 122.500 µs | 76.954 µs | -45.546 µs |
| step1a-3162318e2 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 27.725 µs | -19.675 µs |
| step1a-3162318e2 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 8.960 ms | -5.040 ms |
| step1a-3162318e2 | document create allocations | — | 2997 alloc/op | 3001.04 alloc/op | 4.039999999999964 alloc/op |
| step1b-1cf6a0b23 | document_create/4 | 36.800 µs | 34.600 µs | 23.888 µs | -10.712 µs |
| step1b-1cf6a0b23 | document_create/16 | 127.700 µs | 122.500 µs | 75.143 µs | -47.357 µs |
| step1b-1cf6a0b23 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 27.636 µs | -19.764 µs |
| step1b-1cf6a0b23 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.350 ms | -4.650 ms |
| step1b-1cf6a0b23 | document create allocations | — | 2997 alloc/op | 3010.98 alloc/op | 13.980000000000018 alloc/op |
| step1-45c81aed5 | document_create/4 | 36.800 µs | 34.600 µs | 23.039 µs | -11.561 µs |
| step1-45c81aed5 | document_create/16 | 127.700 µs | 122.500 µs | 78.256 µs | -44.244 µs |
| step1-45c81aed5 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 35.146 µs | -12.254 µs |
| step1-45c81aed5 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.360 ms | -4.640 ms |
| step1-45c81aed5 | document create allocations | — | 2997 alloc/op | 3024.445 alloc/op | 27.445000000000164 alloc/op |
| step2-23c8fde54 | document_create/4 | 36.800 µs | 34.600 µs | 23.581 µs | -11.019 µs |
| step2-23c8fde54 | document_create/16 | 127.700 µs | 122.500 µs | 78.345 µs | -44.155 µs |
| step2-23c8fde54 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 35.995 µs | -11.405 µs |
| step2-23c8fde54 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 8.617 ms | -5.383 ms |
| step2-23c8fde54 | document create allocations | — | 2997 alloc/op | 3056.8 alloc/op | 59.80000000000018 alloc/op |
| step3-711555a37 | document_create/4 | 36.800 µs | 34.600 µs | 30.673 µs | -3.927 µs |
| step3-711555a37 | document_create/16 | 127.700 µs | 122.500 µs | 87.860 µs | -34.640 µs |
| step3-711555a37 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 41.209 µs | -6.191 µs |
| step3-711555a37 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.008 ms | -4.992 ms |
| step3-711555a37 | document create allocations | — | 2997 alloc/op | 2983.855 alloc/op | -13.144999999999982 alloc/op |
| step4-965fb4e6e | document_create/4 | 36.800 µs | 34.600 µs | 31.099 µs | -3.501 µs |
| step4-965fb4e6e | document_create/16 | 127.700 µs | 122.500 µs | 88.191 µs | -34.309 µs |
| step4-965fb4e6e | document_create_branchable/14 | 48.500 µs | 47.400 µs | 41.479 µs | -5.921 µs |
| step4-965fb4e6e | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.243 ms | -4.757 ms |
| step4-965fb4e6e | document create allocations | — | 2997 alloc/op | 2985.875 alloc/op | -11.125 alloc/op |
| step5-c2502fc5c | document_create/4 | 36.800 µs | 34.600 µs | 37.145 µs | 2.545 µs |
| step5-c2502fc5c | document_create/16 | 127.700 µs | 122.500 µs | 101.650 µs | -20.850 µs |
| step5-c2502fc5c | document_create_branchable/14 | 48.500 µs | 47.400 µs | 46.098 µs | -1.302 µs |
| step5-c2502fc5c | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 8.840 ms | -5.160 ms |
| step5-c2502fc5c | document create allocations | — | 2997 alloc/op | 3414.545 alloc/op | 417.5450000000001 alloc/op |
| forcedread-d230f33fb | document_create/4 | 36.800 µs | 34.600 µs | 37.471 µs | 2.871 µs |
| forcedread-d230f33fb | document_create/16 | 127.700 µs | 122.500 µs | 101.090 µs | -21.410 µs |
| forcedread-d230f33fb | document_create_branchable/14 | 48.500 µs | 47.400 µs | 47.171 µs | -0.229 µs |
| forcedread-d230f33fb | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.207 ms | -4.793 ms |
| forcedread-d230f33fb | document create allocations | — | 2997 alloc/op | 3414.565 alloc/op | 417.56500000000005 alloc/op |
| arrival-bafceb60c | document_create/4 | 36.800 µs | 34.600 µs | 37.463 µs | 2.863 µs |
| arrival-bafceb60c | document_create/16 | 127.700 µs | 122.500 µs | 105.367 µs | -17.133 µs |
| arrival-bafceb60c | document_create_branchable/14 | 48.500 µs | 47.400 µs | 47.342 µs | -0.058 µs |
| arrival-bafceb60c | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 11.208 ms | -2.792 ms |
| arrival-bafceb60c | document create allocations | — | 2997 alloc/op | 3413.55 alloc/op | 416.5500000000002 alloc/op |
| acpcounter-a4487cef0 | document_create/4 | 36.800 µs | 34.600 µs | 37.189 µs | 2.589 µs |
| acpcounter-a4487cef0 | document_create/16 | 127.700 µs | 122.500 µs | 101.575 µs | -20.925 µs |
| acpcounter-a4487cef0 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 46.284 µs | -1.116 µs |
| acpcounter-a4487cef0 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 11.187 ms | -2.813 ms |
| acpcounter-a4487cef0 | document create allocations | — | 2997 alloc/op | 3413.565 alloc/op | 416.56500000000005 alloc/op |
| docqueue-1ceaefaca | document_create/4 | 36.800 µs | 34.600 µs | 37.032 µs | 2.432 µs |
| docqueue-1ceaefaca | document_create/16 | 127.700 µs | 122.500 µs | 100.899 µs | -21.601 µs |
| docqueue-1ceaefaca | document_create_branchable/14 | 48.500 µs | 47.400 µs | 46.615 µs | -0.785 µs |
| docqueue-1ceaefaca | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.006 ms | -4.994 ms |
| docqueue-1ceaefaca | document create allocations | — | 2997 alloc/op | 3413.545 alloc/op | 416.5450000000001 alloc/op |
| collectionlock-b33f571c7 | document_create/4 | 36.800 µs | 34.600 µs | 41.714 µs | 7.114 µs |
| collectionlock-b33f571c7 | document_create/16 | 127.700 µs | 122.500 µs | 108.374 µs | -14.126 µs |
| collectionlock-b33f571c7 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 50.370 µs | 2.970 µs |
| collectionlock-b33f571c7 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.174 ms | -4.826 ms |
| collectionlock-b33f571c7 | document create allocations | — | 2997 alloc/op | 3593.545 alloc/op | 596.5450000000001 alloc/op |
| peergeneration-6262270d1 | document_create/4 | 36.800 µs | 34.600 µs | 41.610 µs | 7.010 µs |
| peergeneration-6262270d1 | document_create/16 | 127.700 µs | 122.500 µs | 108.964 µs | -13.536 µs |
| peergeneration-6262270d1 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 50.581 µs | 3.181 µs |
| peergeneration-6262270d1 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.182 ms | -4.818 ms |
| peergeneration-6262270d1 | document create allocations | — | 2997 alloc/op | 3593.585 alloc/op | 596.585 alloc/op |
| acpengine-d7d8d0c17 | document_create/4 | 36.800 µs | 34.600 µs | 41.339 µs | 6.739 µs |
| acpengine-d7d8d0c17 | document_create/16 | 127.700 µs | 122.500 µs | 107.594 µs | -14.906 µs |
| acpengine-d7d8d0c17 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 50.066 µs | 2.666 µs |
| acpengine-d7d8d0c17 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.289 ms | -4.711 ms |
| acpengine-d7d8d0c17 | document create allocations | — | 2997 alloc/op | 3593.54 alloc/op | 596.54 alloc/op |
| deferredacp-5ae8448a4 | document_create/4 | 36.800 µs | 34.600 µs | 41.144 µs | 6.544 µs |
| deferredacp-5ae8448a4 | document_create/16 | 127.700 µs | 122.500 µs | 107.751 µs | -14.749 µs |
| deferredacp-5ae8448a4 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 50.134 µs | 2.734 µs |
| deferredacp-5ae8448a4 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.042 ms | -4.958 ms |
| deferredacp-5ae8448a4 | document create allocations | — | 2997 alloc/op | 3593.535 alloc/op | 596.5349999999999 alloc/op |
| headcache-5af484fb3 | document_create/4 | 36.800 µs | 34.600 µs | 41.350 µs | 6.750 µs |
| headcache-5af484fb3 | document_create/16 | 127.700 µs | 122.500 µs | 108.660 µs | -13.840 µs |
| headcache-5af484fb3 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 49.563 µs | 2.163 µs |
| headcache-5af484fb3 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 8.838 ms | -5.162 ms |
| headcache-5af484fb3 | document create allocations | — | 2997 alloc/op | 3593.575 alloc/op | 596.5749999999998 alloc/op |
| step6-47a35b111 | document_create/4 | 36.800 µs | 34.600 µs | 36.922 µs | 2.322 µs |
| step6-47a35b111 | document_create/16 | 127.700 µs | 122.500 µs | 98.839 µs | -23.661 µs |
| step6-47a35b111 | document_create_branchable/14 | 48.500 µs | 47.400 µs | 45.566 µs | -1.834 µs |
| step6-47a35b111 | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 8.530 ms | -5.470 ms |
| step6-47a35b111 | document create allocations | — | 2997 alloc/op | 3133.545 alloc/op | 136.54500000000007 alloc/op |
| step7-11b71efcd | document_create/4 | 36.800 µs | 34.600 µs | 37.260 µs | 2.660 µs |
| step7-11b71efcd | document_create/16 | 127.700 µs | 122.500 µs | 98.392 µs | -24.108 µs |
| step7-11b71efcd | document_create_branchable/14 | 48.500 µs | 47.400 µs | 45.795 µs | -1.605 µs |
| step7-11b71efcd | startup/cold_open/embedded/10_collections | 15.200 ms | 14.000 ms | 9.131 ms | -4.869 ms |
| step7-11b71efcd | document create allocations | — | 2997 alloc/op | 3133.525 alloc/op | 136.5250000000001 alloc/op |

## Main and immediate-predecessor comparisons

### main-8a38e96f2 → step0-d6f58d624

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 13 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 13 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 249.19628218527828, "delta": -2.074975975697214, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.2712581609755, "workload": "creates", "writers": 4}, {"candidate_median": 0.0029296875, "delta": 0.0029296875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.002685546875, "delta": 0.002685546875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 244.80023253631467, "delta": -2.218369853570721, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.0186023898854, "workload": "creates", "writers": 64}, {"candidate_median": 0.00244140625, "delta": 0.00244140625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 255.96004873175377, "delta": -0.11118157809659124, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.0361328125, "delta": 0.0068359375, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.029296875, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.5452991452991452, "delta": 0.03894838809347845, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 240.4170459472765, "delta": -2.0106382028961036, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03834210025983903, "delta": 0.0018392850513870782, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03515625, "delta": 0.0087890625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0263671875, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 232.15250918551772, "delta": -0.35226006287402356, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.9156679702283335, "delta": 0.022513658579316864, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 249.19628218527828, "delta": -2.074975975697214, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.2712581609755, "workload": "creates", "writers": 4}, {"candidate_median": 0.0029296875, "delta": 0.0029296875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.002685546875, "delta": 0.002685546875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 244.80023253631467, "delta": -2.218369853570721, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.0186023898854, "workload": "creates", "writers": 64}, {"candidate_median": 0.00244140625, "delta": 0.00244140625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 255.96004873175377, "delta": -0.11118157809659124, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.0361328125, "delta": 0.0068359375, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.029296875, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.5452991452991452, "delta": 0.03894838809347845, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 240.4170459472765, "delta": -2.0106382028961036, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03834210025983903, "delta": 0.0018392850513870782, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03515625, "delta": 0.0087890625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0263671875, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 232.15250918551772, "delta": -0.35226006287402356, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.9156679702283335, "delta": 0.022513658579316864, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → step1a-3162318e2

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 17 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 14 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_pass**.

Observed regressions vs main: `[{"candidate_median": 250.56669610132045, "delta": -0.7045620596550464, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.2712581609755, "workload": "creates", "writers": 4}, {"candidate_median": 0.0029296875, "delta": 0.0029296875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.001953125, "delta": 0.001953125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 0.0028076171875, "delta": 0.0028076171875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 226.89774531019157, "delta": -29.173484999658797, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 241.24498433978798, "delta": -6.817436789413222, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0624211292012, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0537109375, "delta": 0.0244140625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.029296875, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.5264957264957265, "delta": 0.02014496929005971, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 242.31316537409387, "delta": -0.11451877607873939, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03847372757812005, "delta": 0.0019709123696681, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 231.88993041546607, "delta": -6.457835497342302, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.34776591280837, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.0361328125, "delta": 0.009765625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0263671875, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 238.84234406386187, "delta": -2.0559879298567694, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.0004885197850512946, "delta": 0.0004885197850512946, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 230.18881904198813, "delta": -2.3159502064036133, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.9249605553802462, "delta": 0.031806243731229644, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 0.035912999494183105, "delta": 0.0016348604878072479, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03427813900637586, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 252.42008371521933, "delta": -3.0593768838101596, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 255.4794605990295, "workload": "creates", "writers": 1}, {"candidate_median": 0.0028076171875, "delta": 0.0003662109375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.00244140625, "workload": "creates", "writers": 64}, {"candidate_median": 226.89774531019157, "delta": -29.062303421562206, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 255.96004873175377, "workload": "shared_updates", "writers": 1}, {"candidate_median": 241.24498433978798, "delta": -9.290390243786845, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.53537458357482, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0537109375, "delta": 0.017578125, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0361328125, "workload": "shared_updates", "writers": 4}, {"candidate_median": 1.8194206756671103, "delta": 0.039903596004267294, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.779517079662843, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03847372757812005, "delta": 0.0001316273182810218, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03834210025983903, "workload": "shared_updates", "writers": 64}, {"candidate_median": 231.88993041546607, "delta": -14.730686755036828, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.6206171705029, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.0361328125, "delta": 0.0009765625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.03515625, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 238.84234406386187, "delta": -10.97401726156636, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 249.81636132542823, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.0004885197850512946, "delta": 0.0004885197850512946, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 230.18881904198813, "delta": -1.9636901435295897, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.15250918551772, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.9249605553802462, "delta": 0.00929258515191278, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.9156679702283335, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 0.035912999494183105, "delta": 0.002222147759167334, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03369085173501577, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → step1b-1cf6a0b23

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 21 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 17 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 244.38281727114045, "delta": -6.888440889835039, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.2712581609755, "workload": "creates", "writers": 4}, {"candidate_median": 0.0029296875, "delta": 0.0029296875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.001708984375, "delta": 0.001708984375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 240.65731895096167, "delta": -6.361283438923721, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.0186023898854, "workload": "creates", "writers": 64}, {"candidate_median": 0.00262451171875, "delta": 0.00262451171875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 239.68997607147816, "delta": -16.381254238372208, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 242.74220224010872, "delta": -5.320218889092473, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0624211292012, "workload": "shared_updates", "writers": 4}, {"candidate_median": 234.65946148070373, "delta": -11.449915872535001, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.10937735323873, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.5236932095749878, "delta": 0.01734245236932097, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 210.31595967703555, "delta": -32.11172447313706, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 1.9611675126903554, "delta": 0.12099322625438669, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8401742864359687, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03959390862944162, "delta": 0.00309109342098967, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 228.4241934745709, "delta": -9.923572438237471, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.34776591280837, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 231.93979757929824, "delta": -2.011866499011603, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 233.95166407830985, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.0458984375, "delta": 0.01953125, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0263671875, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 188.8390985566185, "delta": -52.05923343710015, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.5943833943833944, "delta": 0.048951054373624014, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5454323400097704, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.0007329587099926704, "delta": 0.0007329587099926704, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 150.69330036646792, "delta": -81.81146888192382, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.326556870818322, "delta": 0.43340255916930537, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 0.05451502864130785, "delta": 0.02023688963493199, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03427813900637586, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 251.7329379028434, "delta": -0.6871458123759453, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 252.42008371521933, "workload": "creates", "writers": 1}, {"candidate_median": 244.38281727114045, "delta": -6.183878830179992, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.56669610132045, "workload": "creates", "writers": 4}, {"candidate_median": 240.65731895096167, "delta": -9.35364465314126, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.01096360410293, "workload": "creates", "writers": 64}, {"candidate_median": 234.65946148070373, "delta": -18.337989407862494, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 252.99745088856622, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.0004885197850512946, "delta": 0.00024431954085105036, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0002442002442002442, "workload": "shared_updates", "writers": 16}, {"candidate_median": 210.31595967703555, "delta": -31.99720569705832, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.31316537409387, "workload": "shared_updates", "writers": 64}, {"candidate_median": 1.9611675126903554, "delta": 0.1417468370232451, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8194206756671103, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.03959390862944162, "delta": 0.0011201810513215699, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03847372757812005, "workload": "shared_updates", "writers": 64}, {"candidate_median": 228.4241934745709, "delta": -3.4657369408951695, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 231.88993041546607, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 231.93979757929824, "delta": -19.650740171828176, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.59053775112642, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.0458984375, "delta": 0.009765625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0361328125, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 188.8390985566185, "delta": -50.00324550724338, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.84234406386187, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.5943833943833944, "delta": 0.06763040146866195, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5267529929147324, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.0007329587099926704, "delta": 0.0002444389249413758, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0004885197850512946, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 150.69330036646792, "delta": -79.4955186755202, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 230.18881904198813, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.326556870818322, "delta": 0.4015963154380757, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.9249605553802462, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 0.05451502864130785, "delta": 0.018602029147124742, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.035912999494183105, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → step1-45c81aed5

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 8 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 3 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 0.00390625, "delta": 0.00390625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.001708984375, "delta": 0.001708984375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 0.00274658203125, "delta": 0.00274658203125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 249.72367417001993, "delta": -6.347556139830431, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.040914866581956796, "delta": 0.004412051373504845, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0002442002442002442, "delta": 0.0002442002442002442, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 228.33121933930514, "delta": -4.173549909086603, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 0.03906646372399797, "delta": 0.004788324717622111, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03427813900637586, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 0.00390625, "delta": 0.0009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0029296875, "workload": "creates", "writers": 4}, {"candidate_median": 0.00274658203125, "delta": 0.0001220703125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.00262451171875, "workload": "creates", "writers": 64}, {"candidate_median": 0.040914866581956796, "delta": 0.0013209579525151754, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03959390862944162, "workload": "shared_updates", "writers": 64}]`

### main-8a38e96f2 → step2-23c8fde54

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 8 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 10 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 245.99465922532823, "delta": -3.101727818886502, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 249.09638704421474, "workload": "creates", "writers": 1}, {"candidate_median": 0.0029296875, "delta": 0.0029296875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 4}, {"candidate_median": 0.001953125, "delta": 0.001953125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 16}, {"candidate_median": 0.00799560546875, "delta": 0.00799560546875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "creates", "writers": 64}, {"candidate_median": 0.5130710969948693, "delta": 0.006720339789202501, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.04543134252169474, "delta": 0.008928527313242791, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0002442002442002442, "delta": 0.0002442002442002442, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.04383282364933741, "delta": 0.009554684642961553, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03427813900637586, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 245.99465922532823, "delta": -8.311334547109396, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 254.30599377243763, "workload": "creates", "writers": 1}, {"candidate_median": 265.2876688249241, "delta": -8.72824985210923, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 274.0159186770333, "workload": "creates", "writers": 4}, {"candidate_median": 0.001953125, "delta": 0.000244140625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.001708984375, "workload": "creates", "writers": 16}, {"candidate_median": 0.00799560546875, "delta": 0.0052490234375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.00274658203125, "workload": "creates", "writers": 64}, {"candidate_median": 254.5932476831558, "delta": -5.704636427409156, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 260.29788411056495, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.5130710969948693, "delta": 0.008797592721365044, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5042735042735043, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.0007329587099926704, "delta": 0.0004887584657924262, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0002442002442002442, "workload": "shared_updates", "writers": 16}, {"candidate_median": 247.11455164746565, "delta": -5.331057236165805, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 252.44560888363145, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.04543134252169474, "delta": 0.004516475939737946, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.040914866581956796, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.04383282364933741, "delta": 0.004766359925339442, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03906646372399797, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → step3-711555a37

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 13 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 17 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_pass / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 235.74092578730622, "delta": -20.33030452254414, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 244.49959480877698, "delta": -3.5628263204242216, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0624211292012, "workload": "shared_updates", "writers": 4}, {"candidate_median": 226.84551517218785, "delta": -19.263862181050882, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.10937735323873, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.5995115995115995, "delta": 0.09316084230593269, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 210.88154382059258, "delta": -31.546140329580027, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 2.0168427793788024, "delta": 0.1766684929428337, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8401742864359687, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.04924751841178354, "delta": 0.01274470320333159, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 234.2276250190955, "delta": -4.120140893712858, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.34776591280837, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 225.55121038772353, "delta": -15.347121605995113, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.591552734375, "delta": 0.04612039436522963, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5454323400097704, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 202.23570296504136, "delta": -30.269066283350384, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.308023285244242, "delta": 0.41486897359522534, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 0.03525843548590926, "delta": 0.0009802964795334046, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03427813900637586, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 259.5022368032249, "delta": -5.785432021699194, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 265.2876688249241, "workload": "creates", "writers": 4}, {"candidate_median": 260.79330557082693, "delta": -2.439150104090629, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 263.23245567491756, "workload": "creates", "writers": 16}, {"candidate_median": 235.74092578730622, "delta": -25.155613065959216, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 260.89653885326544, "workload": "shared_updates", "writers": 1}, {"candidate_median": 244.49959480877698, "delta": -10.093652874378819, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 254.5932476831558, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0205078125, "delta": 0.0166015625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.00390625, "workload": "shared_updates", "writers": 4}, {"candidate_median": 226.84551517218785, "delta": -27.044496760642716, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 253.89001193283056, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.5995115995115995, "delta": 0.08644050251673019, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5130710969948693, "workload": "shared_updates", "writers": 16}, {"candidate_median": 210.88154382059258, "delta": -36.23300782687306, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.11455164746565, "workload": "shared_updates", "writers": 64}, {"candidate_median": 2.0168427793788024, "delta": 0.36045146672355743, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.656391312655245, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.04924751841178354, "delta": 0.0038161758900887993, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.04543134252169474, "workload": "shared_updates", "writers": 64}, {"candidate_median": 234.2276250190955, "delta": -17.540891206196818, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.76851622529233, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 242.37102769616646, "delta": -24.149752436101124, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 266.5207801322676, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.01953125, "delta": 0.0009765625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0185546875, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 225.55121038772353, "delta": -35.34449218302058, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 260.8957025707441, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.591552734375, "delta": 0.0779996208218865, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5135531135531135, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 202.23570296504136, "delta": -36.31519843854906, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.55090140359042, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.308023285244242, "delta": 0.5708421627952625, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.7371811224489795, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → step4-965fb4e6e

Strict no-tolerance baseline comparison: **observed_fail** (72 metric cells, 13 regressions, 0 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (72 metric cells, 11 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_pass / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 250.11782033190914, "delta": -1.1534378290663483, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.2712581609755, "workload": "creates", "writers": 4}, {"candidate_median": 230.81343591157278, "delta": -25.257794398277582, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 237.4180786933737, "delta": -8.691298659865026, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.10937735323873, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.588623046875, "delta": 0.0822722896693332, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5063507572056668, "workload": "shared_updates", "writers": 16}, {"candidate_median": 209.60295406274767, "delta": -32.82473008742494, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 2.008024651730115, "delta": 0.16785036529414632, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8401742864359687, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.04864311315924219, "delta": 0.01214029795079024, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.03650281520845195, "workload": "shared_updates", "writers": 64}, {"candidate_median": 234.35894360875238, "delta": -3.9888223040559865, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.34776591280837, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 227.83195326968817, "delta": -13.066378724030471, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.6061050061050061, "delta": 0.060672666095235694, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.5454323400097704, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.0002442002442002442, "delta": 0.0002442002442002442, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 201.44078107052854, "delta": -31.063988177863195, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.3584739360362628, "delta": 0.46531962438724617, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 1.8931543116490166, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 251.33331637095253, "delta": -4.994879843275243, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.3281962142278, "workload": "creates", "writers": 1}, {"candidate_median": 250.11782033190914, "delta": -9.384416471315745, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 259.5022368032249, "workload": "creates", "writers": 4}, {"candidate_median": 230.81343591157278, "delta": -4.927489875733443, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 235.74092578730622, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.0234375, "delta": 0.0029296875, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0205078125, "workload": "shared_updates", "writers": 4}, {"candidate_median": 209.60295406274767, "delta": -1.2785897578449124, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 210.88154382059258, "workload": "shared_updates", "writers": 64}, {"candidate_median": 237.36982871269143, "delta": -5.001198983475035, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.37102769616646, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.025390625, "delta": 0.005859375, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.01953125, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.6061050061050061, "delta": 0.014552271730006061, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 0.591552734375, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.0002442002442002442, "delta": 0.0002442002442002442, "gate_metric": true, "metric": "legacy_http_exhausted_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 201.44078107052854, "delta": -0.7949218945128109, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 202.23570296504136, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.3584739360362628, "delta": 0.050450650792020824, "gate_metric": true, "metric": "legacy_http_conflicts_per_commit", "observed_pass": false, "reference_median": 2.308023285244242, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → step5-c2502fc5c

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 14 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (48 metric cells, 13 regressions, 60 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 245.89162070936268, "delta": -3.204766334852053, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 249.09638704421474, "workload": "creates", "writers": 1}, {"candidate_median": 251.68912133283752, "delta": -4.382108977012848, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 244.92746706628915, "delta": -3.134954062912044, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0624211292012, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0068359375, "delta": 0.0068359375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 171.58366361244006, "delta": -74.52571374079866, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.10937735323873, "workload": "shared_updates", "writers": 16}, {"candidate_median": 1.112859601671994, "delta": 1.112859601671994, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 57.94885667656348, "delta": -184.47882747360913, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 4.039364021028337, "delta": 4.039364021028337, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 228.41808126525325, "delta": -5.533582813056597, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 233.95166407830985, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.005859375, "delta": 0.005859375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 150.44182148474127, "delta": -90.45651050897737, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 1.1122323406349988, "delta": 1.1122323406349988, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 39.87139103998394, "delta": -192.6333782084078, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 4.040374263009484, "delta": 4.040374263009484, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 245.89162070936268, "delta": -5.441695661589847, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.33331637095253, "workload": "creates", "writers": 1}, {"candidate_median": 244.92746706628915, "delta": -20.83902227039536, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 265.7664893366845, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0068359375, "delta": 0.0068359375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 171.58366361244006, "delta": -65.83441508093364, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 237.4180786933737, "workload": "shared_updates", "writers": 16}, {"candidate_median": 1.112859601671994, "delta": 1.112859601671994, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 57.94885667656348, "delta": -151.6540973861842, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 209.60295406274767, "workload": "shared_updates", "writers": 64}, {"candidate_median": 4.039364021028337, "delta": 4.039364021028337, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 228.41808126525325, "delta": -8.95174744743818, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 237.36982871269143, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.005859375, "delta": 0.005859375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 150.44182148474127, "delta": -77.3901317849469, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 227.83195326968817, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 1.1122323406349988, "delta": 1.1122323406349988, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 39.87139103998394, "delta": -161.5693900305446, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 201.44078107052854, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 4.040374263009484, "delta": 4.040374263009484, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → forcedread-d230f33fb

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 14 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 14 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 248.08008448413793, "delta": -1.0163025600768094, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 249.09638704421474, "workload": "creates", "writers": 1}, {"candidate_median": 247.13519864094945, "delta": -8.93603166890091, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 248.01169069951013, "delta": -0.05073042969107178, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0624211292012, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.005859375, "delta": 0.005859375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 167.0706695421499, "delta": -79.03870781108884, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.10937735323873, "workload": "shared_updates", "writers": 16}, {"candidate_median": 1.1133513646422424, "delta": 1.1133513646422424, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 56.92926752487318, "delta": -185.49841662529943, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 4.03242758267111, "delta": 4.03242758267111, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 224.512791910444, "delta": -9.438872167865838, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 233.95166407830985, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.0068359375, "delta": 0.0068359375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 147.21510649345393, "delta": -93.68322550026471, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 1.1124507874015748, "delta": 1.1124507874015748, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 39.09562320859603, "delta": -193.4091460397957, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 4.040635815921036, "delta": 4.040635815921036, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 526.1990877331635, "delta": -8.556325963664221, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 534.7554136968278, "workload": "creates", "writers": 4}, {"candidate_median": 2015.7751879162251, "delta": -75.0743329934271, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 2090.8495209096523, "workload": "creates", "writers": 16}, {"candidate_median": 7417.273926995713, "delta": -92.03909583611039, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 7509.313022831823, "workload": "creates", "writers": 64}, {"candidate_median": 247.13519864094945, "delta": -4.5539226918880615, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.68912133283752, "workload": "shared_updates", "writers": 1}, {"candidate_median": 167.0706695421499, "delta": -4.512994070290176, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 171.58366361244006, "workload": "shared_updates", "writers": 16}, {"candidate_median": 1.1133513646422424, "delta": 0.0004917629702483328, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 1.112859601671994, "workload": "shared_updates", "writers": 16}, {"candidate_median": 56.92926752487318, "delta": -1.0195891516902975, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 57.94885667656348, "workload": "shared_updates", "writers": 64}, {"candidate_median": 1.1013210209054765, "delta": 0.0010774623873377465, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 1.1002435585181387, "workload": "shared_updates", "writers": 64}, {"candidate_median": 224.512791910444, "delta": -3.9052893548092413, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 228.41808126525325, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.0068359375, "delta": 0.0009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.005859375, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 147.21510649345393, "delta": -3.226714991287338, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 150.44182148474127, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 1.1124507874015748, "delta": 0.00021844676657600814, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 1.1122323406349988, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 39.09562320859603, "delta": -0.7757678313879097, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 39.87139103998394, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 4.040635815921036, "delta": 0.00026155291155127713, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 4.040374263009484, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → arrival-bafceb60c

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 13 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 8 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 250.49880623717527, "delta": -5.572424072675091, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 239.99882346201767, "delta": -8.06359766718353, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0624211292012, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0068359375, "delta": 0.0068359375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 165.93232106229888, "delta": -80.17705629093984, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.10937735323873, "workload": "shared_updates", "writers": 16}, {"candidate_median": 1.1128873585833743, "delta": 1.1128873585833743, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 56.70537528673231, "delta": -185.7223088634403, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 4.038999358563181, "delta": 4.038999358563181, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 230.90159115161362, "delta": -3.050072926696231, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 233.95166407830985, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.005859375, "delta": 0.005859375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 147.69155447870608, "delta": -93.20677751501256, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 1.1122323406349988, "delta": 1.1122323406349988, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 39.41299207150431, "delta": -193.09177717688743, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 4.040502435273007, "delta": 4.040502435273007, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 7295.108372477084, "delta": -122.1655545186286, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 7417.273926995713, "workload": "creates", "writers": 64}, {"candidate_median": 239.99882346201767, "delta": -8.012867237492458, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.01169069951013, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0068359375, "delta": 0.0009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.005859375, "workload": "shared_updates", "writers": 4}, {"candidate_median": 165.93232106229888, "delta": -1.138348479851004, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 167.0706695421499, "workload": "shared_updates", "writers": 16}, {"candidate_median": 56.70537528673231, "delta": -0.2238922381408699, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 56.92926752487318, "workload": "shared_updates", "writers": 64}, {"candidate_median": 4.038999358563181, "delta": 0.006571775892071585, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 4.03242758267111, "workload": "shared_updates", "writers": 64}, {"candidate_median": 239.67109830323741, "delta": -9.608975488026829, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 249.28007379126424, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.008122077282795964, "delta": 0.0002480615347644679, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.007874015748031496, "workload": "counters_indexes", "writers": 16}]`

### main-8a38e96f2 → acpcounter-a4487cef0

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 13 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 10 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_pass**.

Observed regressions vs main: `[{"candidate_median": 247.8282155180456, "delta": -8.243014791804768, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 234.4774604533956, "delta": -13.584960675805604, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0624211292012, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0078125, "delta": 0.0078125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 165.76179492049374, "delta": -80.34758243274499, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.10937735323873, "workload": "shared_updates", "writers": 16}, {"candidate_median": 1.1124784641890229, "delta": 1.1124784641890229, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 57.15769860030865, "delta": -185.26998554986397, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 242.4276841501726, "workload": "shared_updates", "writers": 64}, {"candidate_median": 4.034473920287069, "delta": 4.034473920287069, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 220.88945935231177, "delta": -13.062204725998072, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 233.95166407830985, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.005859375, "delta": 0.005859375, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 149.42365378646775, "delta": -91.47467820725089, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 240.89833199371864, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 1.1124507874015748, "delta": 1.1124507874015748, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 39.58027843195142, "delta": -192.9244908164403, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 232.50476924839174, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 4.0376826454755195, "delta": 4.0376826454755195, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 250.74844984076003, "delta": -1.240722664851745, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.98917250561178, "workload": "creates", "writers": 1}, {"candidate_median": 558.6498077902324, "delta": -15.001475411891533, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 573.651283202124, "workload": "creates", "writers": 4}, {"candidate_median": 2025.7589814635774, "delta": -35.729682099981574, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 2061.488663563559, "workload": "creates", "writers": 16}, {"candidate_median": 7116.247534570308, "delta": -178.8608379067764, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 7295.108372477084, "workload": "creates", "writers": 64}, {"candidate_median": 247.8282155180456, "delta": -2.6705907191296774, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.49880623717527, "workload": "shared_updates", "writers": 1}, {"candidate_median": 234.4774604533956, "delta": -5.521363008622075, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 239.99882346201767, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0078125, "delta": 0.0009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0068359375, "workload": "shared_updates", "writers": 4}, {"candidate_median": 165.76179492049374, "delta": -0.1705261418051407, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 165.93232106229888, "workload": "shared_updates", "writers": 16}, {"candidate_median": 220.88945935231177, "delta": -10.01213179930184, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 230.90159115161362, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 1.1124507874015748, "delta": 0.00021844676657600814, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 1.1122323406349988, "workload": "counters_indexes", "writers": 16}]`

### main-8a38e96f2 → docqueue-1ceaefaca

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 7 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 8 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 244.0611392221028, "delta": -12.010091087747554, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.01171875, "delta": 0.01171875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.924074074074074, "delta": 0.924074074074074, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 2.3021741960682203, "delta": 2.3021741960682203, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0078125, "delta": 0.0078125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.869692144373673, "delta": 0.869692144373673, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 2.276625347837086, "delta": 2.276625347837086, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 549.2886179469616, "delta": -9.361189843270836, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 558.6498077902324, "workload": "creates", "writers": 4}, {"candidate_median": 2020.7667578934813, "delta": -4.99222357009603, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 2025.7589814635774, "workload": "creates", "writers": 16}, {"candidate_median": 244.0611392221028, "delta": -3.767076295942786, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.8282155180456, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.01171875, "delta": 0.00390625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0078125, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.0835978835978836, "delta": 0.0762196248669441, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.0073782587309394985, "workload": "shared_updates", "writers": 16}, {"candidate_median": 1.118164188752424, "delta": 0.01818982320512852, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 1.0999743655472956, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0078125, "delta": 0.001953125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.005859375, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.09255801547079222, "delta": 0.08468399972276072, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.007874015748031496, "workload": "counters_indexes", "writers": 16}]`

### main-8a38e96f2 → collectionlock-b33f571c7

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 8 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 10 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 248.1327244341083, "delta": -0.9636626101064394, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 249.09638704421474, "workload": "creates", "writers": 1}, {"candidate_median": 248.0754668672238, "delta": -7.995763442626554, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.0087890625, "delta": 0.0087890625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.898727465535525, "delta": 0.898727465535525, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 2.2373140022892026, "delta": 2.2373140022892026, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.009765625, "delta": 0.009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.8957508577461072, "delta": 0.8957508577461072, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 2.2903916383327036, "delta": 2.2903916383327036, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 248.1327244341083, "delta": -3.605865855510615, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.7385902896189, "workload": "creates", "writers": 1}, {"candidate_median": 524.0613929692462, "delta": -26.828618531389793, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 550.890011500636, "workload": "shared_updates", "writers": 4}, {"candidate_median": 925.2889564604205, "delta": -5.48692649623581, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 930.7758829566563, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.08589607635206786, "delta": 0.002298192754184261, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.0835978835978836, "workload": "shared_updates", "writers": 16}, {"candidate_median": 238.3618211401796, "delta": -7.070261883795496, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 245.43208302397508, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.009765625, "delta": 0.001953125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0078125, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 787.7939959244292, "delta": -0.01866630071333475, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 787.8126622251425, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.8957508577461072, "delta": 0.02605871337243415, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.869692144373673, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 271.92548064588505, "delta": -7.140716112526661, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 279.0661967584117, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.2903916383327036, "delta": 0.013766290495617728, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 2.276625347837086, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → peergeneration-6262270d1

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 7 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 9 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 248.0596719168593, "delta": -8.011558392991077, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.0087890625, "delta": 0.0087890625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.8766720171214554, "delta": 0.8766720171214554, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 2.24445570903561, "delta": 2.24445570903561, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0087890625, "delta": 0.0087890625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.8576379632098107, "delta": 0.8576379632098107, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 2.277135397239836, "delta": 2.277135397239836, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 2043.4042561152307, "delta": -2.2552536981042977, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 2045.659509813335, "workload": "creates", "writers": 16}, {"candidate_median": 248.0596719168593, "delta": -0.01579495036452272, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0754668672238, "workload": "shared_updates", "writers": 1}, {"candidate_median": 921.7683057193283, "delta": -3.520650741092254, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 925.2889564604205, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.09577314071696094, "delta": 0.009877064364893079, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.08589607635206786, "workload": "shared_updates", "writers": 16}, {"candidate_median": 466.8423555851247, "delta": -1.4281930239618532, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 468.2705486090866, "workload": "shared_updates", "writers": 64}, {"candidate_median": 1.100782151557892, "delta": 0.01709907893929863, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 1.0836830726185933, "workload": "shared_updates", "writers": 64}, {"candidate_median": 2.24445570903561, "delta": 0.007141706746407461, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 2.2373140022892026, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.09197547320714476, "delta": 0.00895061863284545, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.08302485457429931, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 270.31636564649716, "delta": -1.6091149993878844, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 271.92548064588505, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → acpengine-d7d8d0c17

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 8 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 13 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 247.57203925179635, "delta": -8.49919105805401, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.009765625, "delta": 0.009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.9085592769803296, "delta": 0.9085592769803296, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 2.2666581404271646, "delta": 2.2666581404271646, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 236.3351799798054, "delta": -2.012585933002981, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.34776591280837, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.009765625, "delta": 0.009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.8840618336886994, "delta": 0.8840618336886994, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 2.2594512580604373, "delta": 2.2594512580604373, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 250.50336130743182, "delta": -1.0031704316525918, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.5065317390844, "workload": "creates", "writers": 1}, {"candidate_median": 7362.91422922834, "delta": -90.43410510277408, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 7453.3483343311145, "workload": "creates", "writers": 64}, {"candidate_median": 247.57203925179635, "delta": -0.48763266506293235, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 248.0596719168593, "workload": "shared_updates", "writers": 1}, {"candidate_median": 501.77182048966114, "delta": -40.08680230606984, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 541.858622795731, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.009765625, "delta": 0.0009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0087890625, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.9085592769803296, "delta": 0.031887259858874195, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.8766720171214554, "workload": "shared_updates", "writers": 16}, {"candidate_median": 466.50209276669904, "delta": -0.3402628184256855, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 466.8423555851247, "workload": "shared_updates", "writers": 64}, {"candidate_median": 2.2666581404271646, "delta": 0.022202431391554533, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 2.24445570903561, "workload": "shared_updates", "writers": 64}, {"candidate_median": 236.3351799798054, "delta": -11.293794834265611, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.628974814071, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 540.05169141682, "delta": -23.2400205852947, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 563.2917120021147, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.009765625, "delta": 0.0009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0087890625, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 780.4199223341137, "delta": -17.516824819684075, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 797.9367471537978, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.8840618336886994, "delta": 0.026423870478888722, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.8576379632098107, "workload": "counters_indexes", "writers": 16}]`

### main-8a38e96f2 → deferredacp-5ae8448a4

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 7 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 13 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 246.83866537858796, "delta": -9.232564931262402, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.009765625, "delta": 0.009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.8812199036918138, "delta": 0.8812199036918138, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 2.2708333333333335, "delta": 2.2708333333333335, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0087890625, "delta": 0.0087890625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.9118421052631579, "delta": 0.9118421052631579, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 2.282375236891977, "delta": 2.282375236891977, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 250.25111673143405, "delta": -0.2522445759977643, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.50336130743182, "workload": "creates", "writers": 1}, {"candidate_median": 566.2633406438023, "delta": -8.130555299190178, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 574.3938959429925, "workload": "creates", "writers": 4}, {"candidate_median": 2034.7817616157972, "delta": -38.085738481559474, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 2072.8675000973567, "workload": "creates", "writers": 16}, {"candidate_median": 246.83866537858796, "delta": -0.733373873208393, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 247.57203925179635, "workload": "shared_updates", "writers": 1}, {"candidate_median": 875.669838404087, "delta": -57.9662241387764, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 933.6360625428634, "workload": "shared_updates", "writers": 16}, {"candidate_median": 0.09577314071696094, "delta": 0.011314575718284745, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.0844585649986762, "workload": "shared_updates", "writers": 16}, {"candidate_median": 460.2885680248134, "delta": -6.213524741885635, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 466.50209276669904, "workload": "shared_updates", "writers": 64}, {"candidate_median": 2.2708333333333335, "delta": 0.004175192906168856, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 2.2666581404271646, "workload": "shared_updates", "writers": 64}, {"candidate_median": 531.7714049459408, "delta": -8.280286470879105, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 540.05169141682, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.9118421052631579, "delta": 0.027780271574458504, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.8840618336886994, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 279.20765629371715, "delta": -8.727287944437137, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 287.9349442381543, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 1.0699936828806065, "delta": 0.01608870607228252, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 1.053904976808324, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.282375236891977, "delta": 0.02292397883153985, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 2.2594512580604373, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → headcache-5af484fb3

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 7 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 10 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_fail**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 250.94975143824132, "delta": -5.1214788716090425, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.009765625, "delta": 0.009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.8773055332798717, "delta": 0.8773055332798717, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 2.25044814340589, "delta": 2.25044814340589, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0107421875, "delta": 0.0107421875, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.8666312433581297, "delta": 0.8666312433581297, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 2.2962776025236593, "delta": 2.2962776025236593, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 249.51072506257262, "delta": -0.7403916688614345, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.25111673143405, "workload": "creates", "writers": 1}, {"candidate_median": 2034.7640713314522, "delta": -0.017690284345007967, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 2034.7817616157972, "workload": "creates", "writers": 16}, {"candidate_median": 7419.991889302151, "delta": -29.95110749356627, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 7449.942996795718, "workload": "creates", "writers": 64}, {"candidate_median": 556.8152521859452, "delta": -0.8918798139789033, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 557.7071319999241, "workload": "shared_updates", "writers": 4}, {"candidate_median": 456.02309838789694, "delta": -4.265469636916464, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 460.2885680248134, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0107421875, "delta": 0.001953125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0087890625, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 744.599262942673, "delta": -38.61054190140794, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 783.209804844081, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.08820403825717323, "delta": 0.010309301415067959, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.07789473684210527, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 272.03643163903814, "delta": -7.171224654679008, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 279.20765629371715, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 2.2962776025236593, "delta": 0.013902365631682123, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 2.282375236891977, "workload": "counters_indexes", "writers": 64}]`

### main-8a38e96f2 → step6-47a35b111

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 8 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 6 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_pass**.

Observed regressions vs main: `[{"candidate_median": 250.26184011616647, "delta": -5.809390193683896, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.001953125, "delta": 0.001953125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.15641088502083844, "delta": 0.15641088502083844, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 1.4139178365343208, "delta": 1.4139178365343208, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 233.41185016207973, "delta": -4.93591575072864, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 238.34776591280837, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.0078125, "delta": 0.0078125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 0.8677488025545503, "delta": 0.8677488025545503, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 2.2654375552468746, "delta": 2.2654375552468746, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 564.2222741659353, "delta": -15.561106816221354, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 579.7833809821567, "workload": "creates", "writers": 4}, {"candidate_median": 7417.145630294404, "delta": -2.846259007746994, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 7419.991889302151, "workload": "creates", "writers": 64}, {"candidate_median": 250.26184011616647, "delta": -0.6879113220748536, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.94975143824132, "workload": "shared_updates", "writers": 1}, {"candidate_median": 233.41185016207973, "delta": -13.440253244636693, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 246.85210340671642, "workload": "counters_indexes", "writers": 1}, {"candidate_median": 0.0890720553044403, "delta": 0.0008680170472670778, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.08820403825717323, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 0.8677488025545503, "delta": 0.0011175591964206477, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.8666312433581297, "workload": "counters_indexes", "writers": 16}]`

### main-8a38e96f2 → step7-11b71efcd

Strict no-tolerance baseline comparison: **observed_fail** (48 metric cells, 7 regressions, 60 schema-distinct metrics); immediate-predecessor comparison: **observed_fail** (84 metric cells, 11 regressions, 0 schema-distinct metrics). Allocation vs main/predecessor: **observed_fail / observed_pass**; Criterion vs main/predecessor: **observed_fail / observed_fail**.

Observed regressions vs main: `[{"candidate_median": 249.96780810088546, "delta": -6.103422208964901, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 256.07123030985036, "workload": "shared_updates", "writers": 1}, {"candidate_median": 0.001953125, "delta": 0.001953125, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.12794117647058822, "delta": 0.12794117647058822, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 16}, {"candidate_median": 2.7034052508448143, "delta": 2.7034052508448143, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0087890625, "delta": 0.0087890625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 1.1477213200628602, "delta": 1.1477213200628602, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 5.409603811434303, "delta": 5.409603811434303, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0, "workload": "counters_indexes", "writers": 64}]`

Observed regressions vs predecessor: `[{"candidate_median": 249.51202197995846, "delta": -2.206353421033185, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 251.71837540099165, "workload": "creates", "writers": 1}, {"candidate_median": 7400.386652586931, "delta": -16.758977707473605, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 7417.145630294404, "workload": "creates", "writers": 64}, {"candidate_median": 249.96780810088546, "delta": -0.29403201528100453, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 250.26184011616647, "workload": "shared_updates", "writers": 1}, {"candidate_median": 522.7413992636513, "delta": -56.44465343846173, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 579.186052702113, "workload": "shared_updates", "writers": 4}, {"candidate_median": 0.4196343471103024, "delta": 0.008923136502415385, "gate_metric": true, "metric": "engine_exhaustions_per_commit", "observed_pass": false, "reference_median": 0.410711210607887, "workload": "shared_updates", "writers": 64}, {"candidate_median": 2.7034052508448143, "delta": 1.2894874143104935, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 1.4139178365343208, "workload": "shared_updates", "writers": 64}, {"candidate_median": 0.0087890625, "delta": 0.0009765625, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.0078125, "workload": "counters_indexes", "writers": 4}, {"candidate_median": 765.7023808897043, "delta": -20.82213238095494, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 786.5245132706592, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 1.1477213200628602, "delta": 0.27997251750830987, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 0.8677488025545503, "workload": "counters_indexes", "writers": 16}, {"candidate_median": 297.6917253935912, "delta": -3.692968518521184, "gate_metric": true, "metric": "commits_per_second", "observed_pass": false, "reference_median": 301.38469391211237, "workload": "counters_indexes", "writers": 64}, {"candidate_median": 5.409603811434303, "delta": 3.144166256187428, "gate_metric": true, "metric": "storage_conflicts_per_commit", "observed_pass": false, "reference_median": 2.2654375552468746, "workload": "counters_indexes", "writers": 64}]`

## Scope limits

The shared-updates workload includes same-field contention among writers in each parity group, so its aggregate conflict count cannot prove the separate disjoint-field target. The focused disjoint-update regression test must provide that evidence. Legacy HTTP retry metrics are not relabeled as current client conflicts.
