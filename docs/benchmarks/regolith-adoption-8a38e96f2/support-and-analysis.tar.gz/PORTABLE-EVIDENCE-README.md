# Frozen benchmark evidence package

Each revision archive contains the original `RUN.json` and `BUILD` metadata unchanged, plus `RUN.portable.json` with extraction-relative paths and SHA-256 values for every archived member. The top-level `index.json` lists the archive hashes and member hashes.

Verify integrity by checking each archive SHA-256 against `index.json`, extracting it, then checking every listed member's SHA-256. Recompute allocation medians from the archived raw allocation samples; do not infer them from timing summaries. The archived analyzer report preserves raw timing rows and its schema distinctions.

Frozen executables are omitted. Their original SHA-256 identities remain recorded in `RUN.json` and `RUN.portable.json`; these hashes identify the binaries used for the measurements but do not make those executables rerunnable. A fresh build is a different binary unless its SHA-256 matches. `BUILD` metadata, cargo dependency-tree provenance, exact source revisions, commands, load-guard attempts, raw logs, Family output, and Criterion JSON are included where recorded.

For verification, compare `shasum -a 256 <label>.tar.gz` with that archive's `sha256` in `index.json`. After extraction, compare each member path and SHA-256 in `index.json` (or the label's `RUN.portable.json`). Recompute the allocation median from the archived raw samples with `statistics.median`; keep workloads/revisions separate.

Extract all archives into one directory to restore the paths listed in each `RUN.portable.json`.
